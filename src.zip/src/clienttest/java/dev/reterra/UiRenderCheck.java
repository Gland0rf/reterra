package dev.reterra;

import dev.reterra.client.MachineScreen;
import dev.reterra.screen.MachineScreenHandler;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Renders the actual screens without a server, a player save, or inventory mutations. */
public final class UiRenderCheck implements ClientModInitializer {
  private int ticks, shot;
  private static final int[][] CASES = {
    {0, 0}, {1, 0}, {2, 0}, {3, 0}, {4, 0}, {1, 1}, {1, 2}, {3, 2}, {1, 3}, {3, 4}, {1, 4}, {1, 5},
    {-1, 0}, {-1, 1}, {-1, 2}, {-1, 3}, {-1, 4}, {-1, 5}, {1, 6}, {1, 7}, {1, 8}, {2, 4}, {4, 4},
    {-1, 6}
  };

  @Override
  public void onInitializeClient() {
    if (!Boolean.getBoolean("reterra.ui-preview")) return;
    ClientTickEvents.END_CLIENT_TICK.register(
        client -> {
          if (client.getOverlay() != null) return;
          GLFW.glfwHideWindow(client.getWindow().getHandle());
          if (ticks++ == 0) show(client);
          if (ticks > 40 && ticks % 30 == 0) {
            try {
              Path output = Path.of("ui-screenshots");
              Files.createDirectories(output);
              try (var image = ScreenshotRecorder.takeScreenshot(client.getFramebuffer())) {
                image.writeTo(
                    output.resolve(
                        "machine-" + CASES[shot][0] + "-page-" + CASES[shot][1] + ".png"));
              }
              if (++shot == CASES.length) {
                client.scheduleStop();
                return;
              }
              show(client);
            } catch (Exception error) {
              throw new IllegalStateException("UI render check failed", error);
            }
          }
        });
  }

  private void show(MinecraftClient client) {
    if (CASES[shot][0] == -1) {
      if (CASES[shot][1] == 6)
        dev.reterra.client.FieldGuideScreen.update(
            new dev.reterra.screen.GuidePayload(
                1,
                0,
                "Establish your first wheat farm.",
                "[x] Recover preserved seeds\n"
                    + "[x] Make organic compost\n"
                    + "[ ] Restore fertile dirt\n"
                    + "[ ] Harvest your first wheat",
                false));
      client.setScreen(
          new dev.reterra.client.FieldGuideScreen(CASES[shot][1] == 6 ? 1 : CASES[shot][1]));
      return;
    }
    PlayerInventory inventory = new PlayerInventory(null);
    MachineScreenHandler handler = new MachineScreenHandler(0, inventory);
    int[] values = {
      CASES[shot][0],
      16,
      100,
      96,
      64,
      1,
      0,
      1,
      0,
      0,
      65,
      40,
      6,
      8,
      5,
      5,
      4,
      2,
      1800,
      7,
      0,
      0,
      3,
      0,
      0,
      3,
      CASES[shot][1],
      0,
      45,
      1,
      9,
      1,
      0,
      0,
      1,
      0
    };
    for (int i = 0; i < values.length; i++) handler.setProperty(i, values[i]);
    if (CASES[shot][1] == 4) {
      handler.setProperty(26, 0);
      if (handler.kind() == 3) {
        handler.setProperty(8, dev.reterra.machine.MachineLogic.Status.INCUBATING.ordinal());
        handler.setProperty(33, 221);
      } else if (handler.kind() == 1) {
        handler.setProperty(20, 1);
        handler.setProperty(34, 2);
        handler.setProperty(8, dev.reterra.machine.MachineLogic.Status.RECLAIMED.ordinal());
      }
      if (handler.kind() == 2) {
        handler.setProperty(39, 1);
        handler.setProperty(40, 42);
      }
      if (handler.kind() == 4) {
        handler.setProperty(21, 1);
        handler.setProperty(25, 4);
        handler.setProperty(8, dev.reterra.machine.MachineLogic.Status.COMPLETE.ordinal());
      }
    }
    if (CASES[shot][1] == 5) {
      handler.setProperty(26, 1);
      handler.setProperty(32, 1);
    }
    if (CASES[shot][1] >= 6) {
      handler.setProperty(26, 2);
      handler.setProperty(23, CASES[shot][1] - 5);
      handler.setProperty(36, 1);
      handler.setProperty(37, 4);
      handler.setProperty(38, 7);
    }
    MachineScreen screen =
        new MachineScreen(
            handler, inventory, Text.translatable("block.reterra." + handler.kindName()));
    client.setScreen(
        new Screen(Text.literal("ReTerra visual check")) {
          @Override
          protected void init() {
            screen.init(client, width, height);
          }

          @Override
          public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            context.fill(0, 0, width, height, 0xFF101914);
            screen.render(context, -100, -100, delta);
          }
        });
  }
}
