package dev.reterra;

import dev.reterra.ecology.Ecology;
import dev.reterra.machine.Multiblocks;
import dev.reterra.state.RestorationState;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeveledCauldronBlock;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.test.GameTest;
import net.minecraft.test.TestContext;
import net.minecraft.util.math.BlockPos;

public class RestorationGameTests implements FabricGameTest {
  @GameTest(templateName = EMPTY_STRUCTURE)
  public void firstFarmhouseIsRecordedAndNeverOverwritesPlayerBuilds(TestContext test) {
    var w = test.getWorld();
    var state = RestorationState.get(w);
    BlockPos previous = state.firstSite;
    boolean pending = state.firstSitePending;
    int cx = (test.getAbsolutePos(BlockPos.ORIGIN).getX() >> 4) + 240;
    int cz = (test.getAbsolutePos(BlockPos.ORIGIN).getZ() >> 4) + 240;
    w.setChunkForced(cx, cz, true);
    w.getChunk(cx, cz);
    for (int x = 0; x < 16; x++)
      for (int z = 0; z < 16; z++) {
        w.setBlockState(
            new BlockPos(cx * 16 + x, 180, cz * 16 + z), Blocks.COARSE_DIRT.getDefaultState());
        for (int y = 181; y < 192; y++)
          w.setBlockState(new BlockPos(cx * 16 + x, y, cz * 16 + z), Blocks.AIR.getDefaultState());
      }
    BlockPos site = new BlockPos(cx * 16 + 8, 181, cz * 16 + 8);
    BlockPos spawn = site.add(32, 0, 32);
    state.protectedBlocks.add(site.asLong());
    dev.reterra.world.ResearchSites.ensureFirstSite(w, spawn);
    test.assertTrue(
        w.getBlockState(site).isAir(), "A player-protected first-site candidate must be skipped.");
    state.protectedBlocks.remove(site.asLong());
    test.assertTrue(
        dev.reterra.world.ResearchSites.ensureFirstSite(w, spawn),
        "A suitable loaded farmhouse site should be placed even after the initial join window.");
    test.assertTrue(
        state.firstSite.equals(site)
            && !state.firstSitePending
            && w.getBlockEntity(
                    dev.reterra.world.ResearchSites.chestPosition(
                        site, dev.reterra.world.ResearchSites.Kind.FARMHOUSE))
                != null,
        "A physical starter ruin and its position must be recorded for retries and directions.");
    state.knownSites.remove(site.asLong());
    state.firstSite = previous;
    state.firstSitePending = pending;
    w.setChunkForced(cx, cz, false);
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void riverRecoveryRefillsOnlyExposedUnprotectedRiverbeds(TestContext test) {
    var w = test.getWorld();
    int cx = (test.getAbsolutePos(BlockPos.ORIGIN).getX() >> 4) + 220;
    int cz = (test.getAbsolutePos(BlockPos.ORIGIN).getZ() >> 4) + 220;
    w.setChunkForced(cx, cz, true);
    w.getChunk(cx, cz);
    BlockPos bed = new BlockPos(cx * 16 + 4, w.getSeaLevel() - 5, cz * 16 + 4);
    var river =
        w.getRegistryManager()
            .get(net.minecraft.registry.RegistryKeys.BIOME)
            .getEntry(net.minecraft.util.Identifier.ofVanilla("river"))
            .orElseThrow();
    net.minecraft.server.command.FillBiomeCommand.fillBiome(
        w, new BlockPos(cx * 16, 48, cz * 16), new BlockPos(cx * 16 + 15, 80, cz * 16 + 15), river);
    for (int dy = 1; dy <= 40; dy++) w.setBlockState(bed.up(dy), Blocks.AIR.getDefaultState());
    w.setBlockState(bed.down(), Blocks.STONE.getDefaultState());
    w.setBlockState(bed, Blocks.GRAVEL.getDefaultState());
    var state = RestorationState.get(w);
    state.protectedBlocks.add(bed.up(2).asLong());
    test.assertFalse(
        dev.reterra.world.RiverRecovery.restoreColumn(w, bed.getX(), bed.getZ()),
        "A protected channel column must never be flooded.");
    state.protectedBlocks.remove(bed.up(2).asLong());
    var pump = new RestorationState.Machine(bed.up(5), "water_restorer");
    pump.water = 10;
    pump.fuel = 10;
    pump.compost = 8;
    pump.riverCursor = 312;
    test.assertTrue(
        dev.reterra.world.RiverRecovery.tick(w, pump) == 1
            && pump.water == 9
            && pump.fuel == 9
            && pump.compost == 7
            && pump.riverRestored == 1,
        "Landscape pumping must charge supplies only for sources actually restored.");
    for (int i = 1; i < 4; i++)
      test.assertTrue(
          dev.reterra.world.RiverRecovery.restoreColumn(w, bed.getX(), bed.getZ()),
          "River sources must rise gradually from the bed.");
    test.assertFalse(
        dev.reterra.world.RiverRecovery.restoreColumn(w, bed.getX(), bed.getZ()),
        "Recovered water must never rise above the old sea level.");
    test.assertTrue(
        w.getBlockState(bed.up(4)).isOf(Blocks.WATER) && w.getBlockState(bed.up(5)).isAir(),
        "Historic waterline must be respected.");
    BlockPos cave = bed.east(4);
    w.setBlockState(cave, Blocks.GRAVEL.getDefaultState());
    w.setBlockState(cave.down(), Blocks.AIR.getDefaultState());
    test.assertFalse(
        dev.reterra.world.RiverRecovery.restoreColumn(w, cave.getX(), cave.getZ()),
        "An unsupported cave roof is not a riverbed.");
    var plains =
        w.getRegistryManager()
            .get(net.minecraft.registry.RegistryKeys.BIOME)
            .getEntry(net.minecraft.util.Identifier.ofVanilla("plains"))
            .orElseThrow();
    net.minecraft.server.command.FillBiomeCommand.fillBiome(
        w,
        new BlockPos(cx * 16, 48, cz * 16),
        new BlockPos(cx * 16 + 15, 80, cz * 16 + 15),
        plains);
    w.setBlockState(bed.up(4), Blocks.AIR.getDefaultState());
    test.assertFalse(
        dev.reterra.world.RiverRecovery.restoreColumn(w, bed.getX(), bed.getZ()),
        "Low plains must not be turned into rivers.");
    w.setChunkForced(cx, cz, false);
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void localSurveyCountsWatersideVegetationAndFertileSlopes(TestContext test) {
    var w = test.getWorld();
    BlockPos p = test.getAbsolutePos(new BlockPos(3, 12, 3));
    w.setBlockState(p, Blocks.GRASS_BLOCK.getDefaultState());
    w.setBlockState(p.up(), Blocks.SUGAR_CANE.getDefaultState());
    w.setBlockState(p.east(), Blocks.WATER.getDefaultState());
    w.setBlockState(p.west(), Blocks.AIR.getDefaultState());
    w.setBlockState(p.west().down(), Blocks.STONE.getDefaultState());
    w.setBlockState(p.up(3), Blocks.OAK_LEAVES.getDefaultState());
    var sector = new RestorationState.Sector();
    dev.reterra.machine.RestorationEngine.sample(w, sector, p);
    test.assertTrue(
        sector.wetland == 1 && sector.slopes == 1 && sector.species.size() == 2,
        "Cane beside water, fertile terraces and native leaf types must be measured from real"
            + " blocks.");
    sector.finish();
    var core = new RestorationState.Machine(p, "restoration_core");
    core.sectors[0] = sector;
    var s = core.survey(0);
    test.assertTrue(
        s.wetland() == 1 && s.slopes() == 1 && s.treeTypes() == 1,
        "Finished surveys must retain the new ecosystem measurements.");
    w.setBlockState(p.up(), Blocks.OAK_LOG.getDefaultState());
    var grown = new RestorationState.Sector();
    dev.reterra.machine.RestorationEngine.sample(w, grown, p);
    test.assertTrue(
        grown.wetland == 1, "Growing a waterside tree must not remove its wetland contribution.");
    var local = dev.reterra.machine.RestorationEngine.localSurvey(w, p);
    test.assertTrue(
        local.sampled() > 0 && local.species() > 0,
        "A scanner survey must work without registering any Core.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void worldOptionDisablesStrippingAndNaturalWildlifeSuppression(TestContext test) {
    var w = test.getWorld();
    var rule = w.getGameRules().get(dev.reterra.world.WorldOptions.BARREN);
    boolean before = rule.get();
    rule.set(false, w.getServer());
    try {
      var p = test.getAbsolutePos(new BlockPos(3, 12, 3));
      w.setBlockState(p, Blocks.GRASS_BLOCK.getDefaultState());
      dev.reterra.world.BarrenWorld.transform(w, w.getChunk(p));
      test.assertTrue(
          w.getBlockState(p).isOf(Blocks.GRASS_BLOCK),
          "Disabling barren generation must preserve new terrain too.");
      var fish = net.minecraft.entity.EntityType.COD.create(w);
      fish.initialize(w, w.getLocalDifficulty(p), net.minecraft.entity.SpawnReason.NATURAL, null);
      test.assertFalse(
          fish.getCommandTags().contains("reterra_barren_spawn"),
          "Ordinary worlds must retain natural wildlife.");
      rule.set(true, w.getServer());
      var barrenFish = net.minecraft.entity.EntityType.COD.create(w);
      barrenFish.initialize(
          w, w.getLocalDifficulty(p), net.minecraft.entity.SpawnReason.NATURAL, null);
      test.assertTrue(
          barrenFish.getCommandTags().contains("reterra_barren_spawn"),
          "Fish must also be suppressed in a dead world.");
    } finally {
      rule.set(before, w.getServer());
    }
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void discoveriesRiverModeAndFinaleSurviveSaving(TestContext test) {
    var state = new RestorationState();
    var p = test.getAbsolutePos(BlockPos.ORIGIN);
    state.firstSite = p;
    state.firstSitePending = true;
    state.heartActivated = true;
    state.heartPos = p.up();
    state.heartCursor = 123;
    state.heartTicks = 140;
    var id = java.util.UUID.randomUUID();
    state.discoveries.put(id, new java.util.HashSet<>(java.util.Set.of("seeds", "wheat")));
    var pump = new RestorationState.Machine(p, "water_restorer");
    pump.riverMode = true;
    pump.riverCursor = 72;
    pump.riverRestored = 30;
    pump.celebratedStage = 2;
    pump.sectors[0].lastWetland = 8;
    pump.sectors[0].lastSlopes = 12;
    state.machines.put(p.asLong(), pump);
    var copy =
        RestorationState.fromNbt(
            state.writeNbt(new NbtCompound(), test.getWorld().getRegistryManager()),
            test.getWorld().getRegistryManager());
    var machine = copy.machines.get(p.asLong());
    test.assertTrue(
        copy.heartPos.equals(p.up())
            && copy.firstSite.equals(p)
            && copy.firstSitePending
            && copy.heartCursor == 123
            && copy.heartTicks == 140
            && copy.discoveries.get(id).contains("wheat"),
        "Journey and finale progress must persist.");
    test.assertTrue(
        machine.riverMode
            && machine.riverRestored == 30
            && machine.riverCursor == 72
            && machine.celebratedStage == 2
            && machine.survey(0).wetland() == 8
            && machine.survey(0).slopes() == 12,
        "River, milestone and biome-specific surveys must persist.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void firstEcosystemImprovesLaterRestorationSupplies(TestContext test) {
    var state = RestorationState.get(test.getWorld());
    var before = java.util.EnumSet.noneOf(Ecology.Family.class);
    before.addAll(state.completed);
    state.completed.add(Ecology.Family.PLAINS);
    var m = new RestorationState.Machine(test.getAbsolutePos(BlockPos.ORIGIN), "restoration_core");
    m.setStack(0, new ItemStack(Content.COMPOST));
    m.setStack(1, new ItemStack(Items.COAL));
    m.setStack(3, new ItemStack(Content.CULTURE));
    dev.reterra.machine.MachineLogic.stock(test.getWorld(), m);
    test.assertTrue(
        m.compost == 40 && m.fuel == 160 && m.culture == 160,
        "The first ecosystem should reduce repeated gathering through 25% greater supply yields.");
    state.completed.clear();
    state.completed.addAll(before);
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void awakenedHeartLightsUpAndHealsBeyondARegion(TestContext test) {
    var w = test.getWorld();
    var state = RestorationState.get(w);
    var completed = java.util.EnumSet.noneOf(Ecology.Family.class);
    completed.addAll(state.completed);
    boolean active = state.heartActivated;
    BlockPos previousHeart = state.heartPos;
    int previousCursor = state.heartCursor, previousTicks = state.heartTicks;
    BlockPos p = test.getAbsolutePos(new BlockPos(3, 12, 3));
    w.setBlockState(p, Content.HEART.getDefaultState());
    for (var part : Multiblocks.parts("heart_of_the_world"))
      w.setBlockState(p.add(part.x(), part.y(), part.z()), part.block().getDefaultState());
    var m = new RestorationState.Machine(p, "heart_of_the_world");
    state.completed.addAll(java.util.EnumSet.allOf(Ecology.Family.class));
    state.heartActivated = false;
    var player = test.createMockCreativeServerPlayerInWorld();
    dev.reterra.machine.MachineLogic.action(w, m, player, 1);
    test.assertTrue(
        state.heartActivated
            && p.equals(state.heartPos)
            && w.getBlockState(p).get(dev.reterra.machine.MachineBlock.LIT),
        "Awakening must permanently light the Heart.");
    BlockPos ground = p.east(5).down();
    w.setBlockState(ground, Blocks.COARSE_DIRT.getDefaultState());
    w.setBlockState(ground.up(), Blocks.AIR.getDefaultState());
    int baseX = ((p.getX() >> 4) - 8) * 16, baseZ = ((p.getZ() >> 4) - 8) * 16;
    state.heartCursor = (ground.getZ() - baseZ) * 272 + ground.getX() - baseX;
    dev.reterra.world.WorldRecovery.tick(w, state);
    test.assertTrue(
        w.getBlockState(ground).isOf(Blocks.DIRT),
        "The finale must perform actual passive terrain recovery.");
    state.heartTicks = 100;
    dev.reterra.machine.MachineLogic.action(w, m, player, 1);
    test.assertTrue(
        state.heartTicks == 100
            && dev.reterra.machine.MachineLogic.status(w, m)
                == dev.reterra.machine.MachineLogic.Status.COMPLETE,
        "An awakened Heart must not reactivate or restart the finale.");
    state.completed.clear();
    state.completed.addAll(completed);
    state.heartActivated = active;
    state.heartPos = previousHeart;
    state.heartCursor = previousCursor;
    state.heartTicks = previousTicks;
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void guideTracksDiscoveriesInsteadOfRestartingAtSeeds(TestContext test) {
    var player = test.createMockCreativeServerPlayerInWorld();
    Journal.discover(player, "seeds");
    Journal.discover(player, "compost");
    test.assertTrue(
        Journal.payload(player).chapter() == 1
            && Journal.payload(player).checklist().contains("[x] Make organic compost"),
        "First-growth notes must show completed discoveries.");
    Journal.discover(player, "dirt");
    Journal.discover(player, "wheat");
    test.assertTrue(
        Journal.payload(player).chapter() == 2,
        "A working farm must advance the guide toward machinery.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void upgradedReservesAndIncubationProgressPersist(TestContext test) {
    var state = new RestorationState();
    var legacy =
        new RestorationState.Machine(test.getAbsolutePos(BlockPos.ORIGIN), "restoration_core");
    legacy.compost = 256;
    legacy.fuel = 2048;
    legacy.water = 2048;
    legacy.culture = 1024;
    state.machines.put(legacy.pos.asLong(), legacy);
    var chamber = new RestorationState.Machine(legacy.pos.east(), "revival_chamber");
    chamber.pendingSpecies = "bee_sample";
    chamber.revivalTicks = 175;
    chamber.water = 16;
    chamber.setStack(3, new ItemStack(Content.BEE_SAMPLE));
    chamber.setStack(4, new ItemStack(Items.POPPY, 2));
    state.machines.put(chamber.pos.asLong(), chamber);
    var nbt = state.writeNbt(new NbtCompound(), test.getWorld().getRegistryManager());
    nbt.getList("machines", net.minecraft.nbt.NbtElement.COMPOUND_TYPE)
        .getCompound(0)
        .putInt("resourceVersion", 2);
    var restored = RestorationState.fromNbt(nbt, test.getWorld().getRegistryManager());
    var migrated = restored.machines.get(legacy.pos.asLong());
    test.assertTrue(
        migrated.compost == 32
            && migrated.fuel == 128
            && migrated.water == 128
            && migrated.culture == 128,
        "An old dose must convert once to a new dose without losing its item value.");
    var pending = restored.machines.get(chamber.pos.asLong());
    test.assertTrue(
        pending.revivalTicks == 175
            && pending.pendingSpecies.equals("bee_sample")
            && pending.getStack(4).getCount() == 2
            && pending.water == 16,
        "Saving must preserve incubation and its reserved inputs.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE, tickLimit = 80)
  public void nearbyHomeAnimalsAndShelteredBeesStayInTheCensus(TestContext test) {
    var w = test.getWorld();
    int cx = (test.getAbsolutePos(BlockPos.ORIGIN).getX() >> 4) + 180;
    int cz = (test.getAbsolutePos(BlockPos.ORIGIN).getZ() >> 4) + 180;
    w.setChunkForced(cx, cz, true);
    w.setChunkForced(cx + 2, cz, true);
    w.getChunk(cx, cz);
    w.getChunk(cx + 2, cz);
    test.runAtTick(
        20,
        () -> {
          var core =
              new RestorationState.Machine(
                  new BlockPos(cx * 16 + 8, 180, cz * 16 + 8), "restoration_core");
          var sheep = net.minecraft.entity.EntityType.SHEEP.create(w);
          sheep.refreshPositionAndAngles(cx * 16 + 34, 180, cz * 16 + 8, 0, 0);
          sheep.addCommandTag(dev.reterra.machine.AnimalHabitatGoal.PREFIX + core.pos.asLong());
          test.assertTrue(
              w.spawnEntity(sheep), "Home-animal fixture must spawn into its loaded chunk.");
          test.assertTrue(
              dev.reterra.machine.RestorationEngine.animalCount(w, core) == 1,
              "A home animal just beyond the survey edge must remain counted: "
                  + dev.reterra.machine.RestorationEngine.animalCount(w, core)
                  + ", alive="
                  + sheep.isAlive()
                  + ", baby="
                  + sheep.isBaby()
                  + ", tags="
                  + sheep.getCommandTags());
          test.assertTrue(
              ((dev.reterra.mixin.MobGoalsAccessor) sheep)
                  .reterra$getGoals().getGoals().stream()
                      .anyMatch(
                          goal -> goal.getGoal() instanceof dev.reterra.machine.AnimalHabitatGoal),
              "Loaded home animals need a return-home goal.");
          w.setBlockState(core.pos, Blocks.BEEHIVE.getDefaultState());
          var hive = (net.minecraft.block.entity.BeehiveBlockEntity) w.getBlockEntity(core.pos);
          hive.addBee(net.minecraft.block.entity.BeehiveBlockEntity.BeeData.create(600));
          test.assertTrue(
              dev.reterra.machine.RestorationEngine.animalCount(w, core) == 2
                  && dev.reterra.machine.RestorationEngine.animalSpecies(w, core) == 2,
              "Sheltered bees still count as wildlife.");
          sheep.discard();
          w.setBlockState(core.pos, Blocks.AIR.getDefaultState());
          w.setChunkForced(cx, cz, false);
          w.setChunkForced(cx + 2, cz, false);
          test.complete();
        });
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void everyMachineCanRotateAndTheCoreNeedsItsFurnace(TestContext test) {
    var w = test.getWorld();
    BlockPos p = test.getAbsolutePos(new BlockPos(3, 12, 3));
    for (String kind : dev.reterra.machine.MachineLogic.KINDS) {
      for (int rotation = 0; rotation < 4; rotation++) {
        for (int dx = -3; dx <= 3; dx++)
          for (int dz = -3; dz <= 3; dz++)
            w.setBlockState(p.add(dx, 0, dz), Blocks.AIR.getDefaultState());
        w.setBlockState(
            p, net.minecraft.registry.Registries.BLOCK.get(Content.id(kind)).getDefaultState());
        for (var part : Multiblocks.parts(kind, rotation))
          w.setBlockState(p.add(part.x(), part.y(), part.z()), part.block().getDefaultState());
        test.assertTrue(
            Multiblocks.issue(w, p, kind) == 0,
            "Valid rotation rejected: " + kind + " " + rotation);
        if (kind.equals("restoration_core")) {
          w.setBlockState(p.down(), Blocks.POLISHED_ANDESITE.getDefaultState());
          test.assertTrue(Multiblocks.issue(w, p, kind) != 0, "A Core must require its furnace.");
        }
      }
    }
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void waterBucketsReturnInTheirInputSlotAndReservesDoNotBurnWhileIdle(TestContext test) {
    var m = new RestorationState.Machine(test.getAbsolutePos(BlockPos.ORIGIN), "restoration_core");
    m.setStack(0, new ItemStack(Content.COMPOST));
    m.setStack(1, new ItemStack(Items.COAL));
    m.setStack(2, new ItemStack(Items.WATER_BUCKET));
    m.setStack(3, new ItemStack(Content.CULTURE));
    dev.reterra.machine.MachineLogic.stock(m);
    test.assertTrue(
        m.getStack(2).isOf(Items.BUCKET) && m.getStack(7).isEmpty(),
        "Empty bucket must stay in the water slot.");
    int water = m.water, fuel = m.fuel, compost = m.compost;
    for (int i = 0; i < 20; i++) dev.reterra.machine.MachineLogic.stock(m);
    test.assertTrue(
        m.water == water && m.fuel == fuel && m.compost == compost,
        "Waiting must preserve stored supplies.");
    test.assertTrue(
        water < 256 && fuel < 256 && compost < 256, "One item must not restore an entire region.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void pumpSuppliesNearbyMachinesDirectlyFromAPond(TestContext test) {
    var w = test.getWorld();
    var state = RestorationState.get(w);
    BlockPos p = test.getAbsolutePos(new BlockPos(3, 12, 3));
    var pump = new RestorationState.Machine(p, "water_restorer");
    var core = new RestorationState.Machine(p.east(6), "restoration_core");
    pump.fuel = 128;
    pump.compost = 8;
    w.setBlockState(p.north(), Blocks.WATER.getDefaultState());
    state.machines.put(p.asLong(), pump);
    state.machines.put(core.pos.asLong(), core);
    dev.reterra.machine.MachineLogic.pump(w, pump);
    test.assertTrue(
        core.water == 32 && pump.fuel == 127 && pump.compost == 7,
        "Pump must transfer water while charging for actual pumping.");
    test.assertTrue(
        w.getBlockState(p.north()).isOf(Blocks.WATER) && core.getStack(2).isEmpty(),
        "Pond-fed irrigation needs no bucket hauling.");
    state.machines.remove(p.asLong());
    state.machines.remove(core.pos.asLong());
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void flowersCanBeCultivatedWithoutFindingMoreRuins(TestContext test) {
    var w = test.getWorld();
    BlockPos p = test.getAbsolutePos(new BlockPos(3, 12, 3));
    for (int dx = -2; dx <= 2; dx++)
      for (int dz = -2; dz <= 2; dz++) {
        w.setBlockState(p.add(dx, 0, dz), Blocks.GRASS_BLOCK.getDefaultState());
        w.setBlockState(p.add(dx, 1, dz), Blocks.AIR.getDefaultState());
      }
    var player = test.createMockPlayer(net.minecraft.world.GameMode.SURVIVAL);
    player.setStackInHand(net.minecraft.util.Hand.MAIN_HAND, new ItemStack(Content.COMPOST));
    var hit =
        new net.minecraft.util.hit.BlockHitResult(
            net.minecraft.util.math.Vec3d.ofCenter(p),
            net.minecraft.util.math.Direction.UP,
            p,
            false);
    dev.reterra.machine.MachineInteraction.use(player, w, net.minecraft.util.Hand.MAIN_HAND, hit);
    int flowers = 0;
    for (int dx = -2; dx <= 2; dx++)
      for (int dz = -2; dz <= 2; dz++)
        if (w.getBlockState(p.add(dx, 1, dz)).isIn(net.minecraft.registry.tag.BlockTags.FLOWERS))
          flowers++;
    test.assertTrue(
        flowers == 5 && player.getMainHandStack().isEmpty(),
        "One compost should grow enough flowers to keep a habitat and supply two bee food.");
    test.assertTrue(
        dev.reterra.machine.MachineLogic.foodMatches(
                new ItemStack(Content.BEE_SAMPLE), new ItemStack(Items.POPPY))
            && dev.reterra.machine.MachineLogic.foodCount(new ItemStack(Content.BEE_SAMPLE)) == 2,
        "Bees accept two flowers, including poppies, rather than demanding one specific flower.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void machinesShowStoredSuppliesAndActivity(TestContext test) {
    var w = test.getWorld();
    BlockPos p = test.getAbsolutePos(new BlockPos(3, 12, 3));
    assemble(w, p);
    var m = new RestorationState.Machine(p, "soil_reclaimer");
    m.setStack(0, new ItemStack(Content.COMPOST));
    dev.reterra.machine.MachineBlock.updateVisual(w, m);
    test.assertTrue(
        w.getBlockState(p).get(dev.reterra.machine.MachineBlock.SUPPLIED)
            && !w.getBlockState(p).get(dev.reterra.machine.MachineBlock.LIT),
        "A stocked but idle machine needs its amber indicator.");
    m.compost = 32;
    m.fuel = 128;
    m.water = 128;
    dev.reterra.machine.MachineBlock.updateVisual(w, m);
    test.assertTrue(
        w.getBlockState(p).get(dev.reterra.machine.MachineBlock.LIT),
        "A working machine needs its lit indicator.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void reclaimedRecoverySpreadsPastItsOriginalBorder(TestContext test) {
    var w = test.getWorld();
    int cx = (test.getAbsolutePos(BlockPos.ORIGIN).getX() >> 4) + 110;
    int cz = (test.getAbsolutePos(BlockPos.ORIGIN).getZ() >> 4) + 110;
    var m =
        new RestorationState.Machine(
            new BlockPos(cx * 16 + 8, 180, cz * 16 + 8), "restoration_core");
    m.reclaimed = true;
    dev.reterra.machine.RestorationEngine.advanceSpread(m, 1200);
    test.assertTrue(
        m.spreadRadius == 2,
        "A reclaimed habitat must reach its next chunk ring after one loaded minute.");
    BlockPos outside = new BlockPos(cx * 16 - 20, 180, cz * 16 + 8);
    w.getChunk(outside);
    w.setBlockState(outside.down(), Blocks.STONE.getDefaultState());
    w.setBlockState(outside, Blocks.GRAVEL.getDefaultState());
    w.setBlockState(outside.up(), Blocks.AIR.getDefaultState());
    var state = new RestorationState();
    int width = 80, baseX = (cx - 2) * 16, baseZ = (cz - 2) * 16;
    m.rewildCursor = (outside.getZ() - baseZ) * width + outside.getX() - baseX;
    dev.reterra.machine.RestorationEngine.rewild(w, state, m);
    test.assertTrue(
        w.getBlockState(outside).isOf(Blocks.DIRT),
        "Natural soil beyond the original 48 x 48 border must heal.");
    dev.reterra.machine.RestorationEngine.advanceSpread(m, 12000);
    test.assertTrue(m.spreadRadius == 4, "Expansion must remain bounded for servers.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void revivalTakesTimeLocksItsInputsAndProducesAPair(TestContext test) {
    var w = test.getWorld();
    int cx = (test.getAbsolutePos(BlockPos.ORIGIN).getX() >> 4) + 130;
    int cz = (test.getAbsolutePos(BlockPos.ORIGIN).getZ() >> 4) + 130;
    w.getChunk(cx, cz);
    BlockPos base = new BlockPos(cx * 16, 180, cz * 16);
    for (int x = 0; x < 16; x++)
      for (int z = 0; z < 16; z++) {
        w.setBlockState(base.add(x, 0, z), Blocks.GRASS_BLOCK.getDefaultState());
        for (int y = 1; y < 6; y++)
          w.setBlockState(base.add(x, y, z), Blocks.AIR.getDefaultState());
      }
    var core = new RestorationState.Machine(base.add(4, 1, 4), "restoration_core");
    core.registered = true;
    for (var sector : core.sectors) {
      sector.surveyed = true;
      sector.lastSampled = 256;
      sector.lastFertile = 200;
      sector.lastGrass = 100;
      sector.lastCrops = 4;
      sector.lastWater = 4;
      sector.lastFlowers = 1;
      sector.lastTrees = 1;
      sector.lastSpecies.addAll(java.util.List.of("wheat", "oak_leaves", "dandelion"));
    }
    var chamber = new RestorationState.Machine(base.add(10, 1, 10), "revival_chamber");
    w.setBlockState(chamber.pos, Content.CHAMBER.getDefaultState());
    for (var part : Multiblocks.parts(chamber.kind))
      w.setBlockState(
          chamber.pos.add(part.x(), part.y(), part.z()), part.block().getDefaultState());
    chamber.setStack(3, new ItemStack(Content.CHICKEN_SAMPLE));
    chamber.setStack(4, new ItemStack(Items.WHEAT_SEEDS, 4));
    chamber.setStack(5, new ItemStack(Content.NUTRIENTS));
    chamber.water = 16;
    var state = RestorationState.get(w);
    state.machines.put(core.pos.asLong(), core);
    state.machines.put(chamber.pos.asLong(), chamber);
    var player = test.createMockCreativeServerPlayerInWorld();
    player.refreshPositionAndAngles(
        chamber.pos.getX(), chamber.pos.getY(), chamber.pos.getZ() + 1, 0, 0);
    dev.reterra.machine.MachineLogic.action(w, chamber, player, 1);
    test.assertTrue(
        !chamber.pendingSpecies.isEmpty()
            && dev.reterra.machine.RestorationEngine.animalCount(w, core) == 0,
        "Revival must start without instant animals.");
    dev.reterra.machine.MachineLogic.action(w, chamber, player, 3);
    test.assertTrue(
        chamber.pendingSpecies.isEmpty()
            && chamber.getStack(3).getCount() == 1
            && chamber.getStack(4).getCount() == 4
            && chamber.water == 16,
        "Cancellation must preserve all unconsumed inputs.");
    dev.reterra.machine.MachineLogic.action(w, chamber, player, 1);
    var handler =
        new dev.reterra.screen.MachineScreenHandler(2, player.getInventory(), w, chamber, false);
    test.assertFalse(
        handler.slots.get(3).canTakeItems(player), "Incubating samples must be locked.");
    for (int i = 0; i < 79; i++) dev.reterra.machine.MachineLogic.revivalTick(w, chamber);
    test.assertTrue(
        dev.reterra.machine.RestorationEngine.animalCount(w, core) == 0,
        "Incubation must finish before birth.");
    dev.reterra.machine.MachineLogic.revivalTick(w, chamber);
    test.assertTrue(
        chamber.pendingSpecies.isEmpty()
            && chamber.getStack(3).isEmpty()
            && dev.reterra.machine.RestorationEngine.animalCount(w, core) == 2,
        "A finished cycle must produce exactly two adults and consume its sample once.");
    test.assertTrue(
        chamber.water == 0 && chamber.getStack(4).isEmpty() && chamber.getStack(5).isEmpty(),
        "Successful revival consumes its reserved inputs.");
    state.machines.remove(core.pos.asLong());
    state.machines.remove(chamber.pos.asLong());
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE, tickLimit = 460)
  public void allTwentyCropsCountAcrossBiomesWithinOneFastSurvey(TestContext test) {
    var w = test.getWorld();
    int cx = (test.getAbsolutePos(BlockPos.ORIGIN).getX() >> 4) + 150;
    int cz = (test.getAbsolutePos(BlockPos.ORIGIN).getZ() >> 4) + 150;
    for (int dx = -1; dx <= 1; dx++)
      for (int dz = -1; dz <= 1; dz++) {
        w.setChunkForced(cx + dx, cz + dz, true);
        w.getChunk(cx + dx, cz + dz);
      }
    BlockPos base = new BlockPos(cx * 16, 180, cz * 16);
    for (int x = 1; x <= 10; x++)
      for (int z = 1; z <= 2; z++) {
        w.setBlockState(
            base.add(x, 0, z),
            Blocks.FARMLAND.getDefaultState().with(net.minecraft.block.FarmlandBlock.MOISTURE, 7));
        w.setBlockState(base.add(x, 1, z), Blocks.WHEAT.getDefaultState());
      }
    var core = new RestorationState.Machine(base.add(8, 1, 8), "restoration_core");
    core.registered = true;
    core.paused = true;
    core.biome = "minecraft:desert";
    w.setBlockState(core.pos, Content.CORE.getDefaultState());
    var state = RestorationState.get(w);
    state.machines.put(core.pos.asLong(), core);
    test.runAtTick(
        400,
        () -> {
          test.assertTrue(
              core.survey(0).crops() == 20,
              "All planted crops in the region must count, including other biome columns: "
                  + core.survey(0).crops());
          test.assertTrue(
              java.util.Arrays.stream(core.sectors).allMatch(s -> s.surveyed),
              "A complete loaded survey must finish in about 18 seconds.");
          state.machines.remove(core.pos.asLong());
          for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++) w.setChunkForced(cx + dx, cz + dz, false);
          test.complete();
        });
  }

  @GameTest(templateName = EMPTY_STRUCTURE, tickLimit = 200)
  public void researchSitesBuildWithoutSignsWithUnattachedGenerationBlockEntities(
      TestContext test) {
    ServerWorld world = test.getWorld();
    var pending = new java.util.HashMap<BlockPos, net.minecraft.block.entity.BlockEntity>();
    int[] unattachedReads = {0};
    // Chunk generation exposes block entities before they have a World. A ServerWorld-only
    // fixture missed the SignBlockEntity.setText crash, which sends updates through that World.
    var generation =
        (net.minecraft.world.StructureWorldAccess)
            java.lang.reflect.Proxy.newProxyInstance(
                getClass().getClassLoader(),
                new Class<?>[] {net.minecraft.world.StructureWorldAccess.class},
                (proxy, method, args) -> {
                  if (method.getName().equals("setBlockState")) {
                    var state = (net.minecraft.block.BlockState) args[1];
                    test.assertFalse(
                        state.getBlock() instanceof net.minecraft.block.AbstractSignBlock,
                        "ReTerra structures must not place signs.");
                    pending.remove((BlockPos) args[0]);
                  }
                  if (method.getName().equals("getBlockEntity")) {
                    BlockPos pos = ((BlockPos) args[0]).toImmutable();
                    if (pending.containsKey(pos)) return pending.get(pos);
                    var live = world.getBlockEntity(pos);
                    if (live == null) return null;
                    var unattached =
                        net.minecraft.block.entity.BlockEntity.createFromNbt(
                            pos,
                            world.getBlockState(pos),
                            live.createNbtWithIdentifyingData(world.getRegistryManager()),
                            world.getRegistryManager());
                    test.assertTrue(
                        unattached != null && unattached.getWorld() == null,
                        "Regression fixture must expose an unattached block entity.");
                    pending.put(pos, unattached);
                    unattachedReads[0]++;
                    return unattached;
                  }
                  try {
                    return method.invoke(world, args);
                  } catch (java.lang.reflect.InvocationTargetException exception) {
                    throw exception.getCause();
                  }
                });
    int cx = (test.getAbsolutePos(BlockPos.ORIGIN).getX() >> 4) + 60;
    int cz = (test.getAbsolutePos(BlockPos.ORIGIN).getZ() >> 4) + 60;
    for (var kind : dev.reterra.world.ResearchSites.Kind.values()) {
      BlockPos surface = new BlockPos((cx + kind.ordinal()) * 16 + 8, 90, cz * 16 + 8);
      world.getChunk(surface);
      dev.reterra.world.ResearchSites.build(generation, surface, kind);
      BlockPos chest = dev.reterra.world.ResearchSites.chestPosition(surface, kind);
      var entity = generation.getBlockEntity(chest);
      test.assertTrue(
          entity instanceof net.minecraft.block.entity.LootableContainerBlockEntity,
          "Every site must retain its loot chest during generation: " + kind);
      var loot = (net.minecraft.block.entity.LootableContainerBlockEntity) entity;
      test.assertTrue(
          loot.getWorld() == null
              && loot.getLootTable() != null
              && loot.getLootTable()
                  .getValue()
                  .equals(Content.id("chests/" + kind.name().toLowerCase(java.util.Locale.ROOT))),
          "Loot must be assigned safely before a generated chest is attached: " + kind);
    }
    test.assertTrue(
        unattachedReads[0] >= 6,
        "All six ruins must exercise the world-generation block-entity lifecycle.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE, tickLimit = 60)
  public void reclaimerConsumesOnlyAfterProducingSoil(TestContext test) {
    ServerWorld w = test.getWorld();
    BlockPos p = test.getAbsolutePos(new BlockPos(3, 2, 3));
    assemble(w, p);
    RestorationState state = RestorationState.get(w);
    RestorationState.Machine m = new RestorationState.Machine(p, "soil_reclaimer");
    m.compost = 256;
    m.fuel = 2048;
    m.water = 2048;
    state.machines.put(p.asLong(), m);
    Inventory inv = (Inventory) w.getBlockEntity(p.north());
    inv.setStack(0, new ItemStack(Items.GRAVEL));
    test.runAtTick(
        25,
        () -> {
          test.assertTrue(
              m.compost == 255 && m.fuel == 2047 && m.water == 2047,
              "One block of work uses one credit, not one whole compost or coal.");
          int dirt = m.getStack(6).isOf(Items.DIRT) ? m.getStack(6).getCount() : 0;
          for (int i = 0; i < inv.size(); i++)
            if (inv.getStack(i).isOf(Items.DIRT)) dirt += inv.getStack(i).getCount();
          test.assertTrue(dirt == 1, "One gravel produces one dirt; material is conserved.");
          state.machines.remove(p.asLong());
          test.complete();
        });
  }

  @GameTest(templateName = EMPTY_STRUCTURE, tickLimit = 60)
  public void blockedOutputDoesNotConsumeResources(TestContext test) {
    ServerWorld w = test.getWorld();
    BlockPos p = test.getAbsolutePos(new BlockPos(3, 2, 3));
    assemble(w, p);
    RestorationState state = RestorationState.get(w);
    RestorationState.Machine m = new RestorationState.Machine(p, "soil_reclaimer");
    m.compost = 2;
    m.fuel = 2;
    m.water = 2;
    state.machines.put(p.asLong(), m);
    Inventory inv = (Inventory) w.getBlockEntity(p.north());
    for (int i = 0; i < inv.size(); i++) inv.setStack(i, new ItemStack(Items.COBBLESTONE, 64));
    inv.setStack(0, new ItemStack(Items.GRAVEL, 64));
    m.setStack(6, new ItemStack(Items.DIRT, 64));
    test.runAtTick(
        25,
        () -> {
          test.assertTrue(
              m.compost == 2 && m.fuel == 2 && m.water == 2,
              "A full output must preserve supplies.");
          test.assertTrue(
              inv.getStack(0).getCount() == 64, "A full output must preserve input gravel.");
          state.machines.remove(p.asLong());
          test.complete();
        });
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void persistenceIncludesMachinesScarsAndProgress(TestContext test) {
    ServerWorld w = test.getWorld();
    RestorationState original = new RestorationState();
    BlockPos p = test.getAbsolutePos(new BlockPos(1, 2, 1));
    RestorationState.Machine m = new RestorationState.Machine(p, "restoration_core");
    m.compost = 17;
    m.water = 32;
    m.reclaimed = true;
    m.sectors[2].cursor = 147;
    m.sectors[2].species.add("minecraft:oak_leaves");
    original.reclaimedRegions.put(p.asLong(), m);
    var replacement = new RestorationState.Machine(p, "water_restorer");
    replacement.water = 96;
    original.machines.put(p.asLong(), replacement);
    original.protectedBlocks.add(p.up().asLong());
    NbtCompound data = original.writeNbt(new NbtCompound(), w.getRegistryManager());
    RestorationState copy = RestorationState.fromNbt(data, w.getRegistryManager());
    var restored = copy.reclaimedRegions.get(p.asLong());
    test.assertTrue(
        copy.machines.get(p.asLong()).water == 96,
        "Reclaimed regions persist independently of a new machine at the same anchor.");
    test.assertTrue(
        restored.compost == 17 && restored.water == 32 && restored.reclaimed,
        "Machine resources and completion survive saving.");
    test.assertTrue(
        restored.sectors[2].cursor == 147
            && restored.sectors[2].species.contains("minecraft:oak_leaves"),
        "Partial sector surveys survive saving.");
    test.assertTrue(
        copy.protectedBlocks.contains(p.up().asLong()), "Player block protection survives saving.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void dataRecipesAndLootAreLoaded(TestContext test) {
    var manager = test.getWorld().getRecipeManager();
    test.assertTrue(
        manager.get(Content.id("recovery_bundle")).isEmpty(),
        "Seed pouches must not have a crafting shortcut.");
    test.assertTrue(
        manager.get(Content.id("restoration_core")).isPresent(), "Core recipe must load.");
    test.assertTrue(
        manager.get(Content.id("bee_sample")).isEmpty(),
        "Biological samples must come from preserved specimens, not stones and food.");
    test.assertTrue(
        manager.get(Content.id("starter_beehive")).isEmpty(),
        "Empty starter hives are salvaged from greenhouses.");
    test.assertTrue(
        test.getWorld().getServer().getAdvancementLoader().get(Content.id("new_beginning")) != null,
        "Endgame advancement must load.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE, tickLimit = 60)
  public void terrainModePreservesPlacedBlocksAndScars(TestContext test) {
    ServerWorld w = test.getWorld();
    // GameTest encloses templates in a roof; restoration deliberately targets outdoor surfaces.
    BlockPos p = test.getAbsolutePos(new BlockPos(3, 12, 3));
    for (int x = 0; x < 8; x++)
      for (int z = 0; z < 8; z++)
        w.setBlockState(
            test.getAbsolutePos(new BlockPos(x, 11, z)), Blocks.COARSE_DIRT.getDefaultState());
    assemble(w, p);
    RestorationState state = RestorationState.get(w);
    BlockPos protectedSoil = p.east().down();
    state.protectedBlocks.add(protectedSoil.asLong());
    BlockPos natural = null;
    for (int dx = 2; dx <= 4; dx++)
      if (!Ecology.isScar(p.getX() + dx, p.getZ())) {
        natural = p.east(dx).down();
        break;
      }
    if (natural == null) throw new AssertionError("No non-scar column in fixture.");
    BlockPos target = natural;
    RestorationState.Machine m = new RestorationState.Machine(p, "soil_reclaimer");
    m.production = false;
    m.cursor = 110;
    m.compost = 256;
    m.fuel = 2048;
    m.water = 2048;
    state.machines.put(p.asLong(), m);
    test.runAtTick(
        25,
        () -> {
          test.assertTrue(
              w.getBlockState(protectedSoil).isOf(Blocks.COARSE_DIRT),
              "Machine must not replace a player-placed soil block.");
          test.assertTrue(
              w.getBlockState(target).isOf(Blocks.DIRT),
              "Natural soil should restore: target="
                  + target
                  + ", ground="
                  + dev.reterra.machine.RestorationEngine.ground(w, target.getX(), target.getZ())
                  + ", state="
                  + w.getBlockState(target)
                  + ", cursor="
                  + m.cursor
                  + ", compost="
                  + m.compost
                  + ", structure="
                  + Multiblocks.missing(w, p));
          state.machines.remove(p.asLong());
          state.protectedBlocks.remove(protectedSoil.asLong());
          test.complete();
        });
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void barrenSpawnsDoNotBlockBreedingOrRevival(TestContext test) {
    ServerWorld w = test.getWorld();
    var natural = net.minecraft.entity.EntityType.SHEEP.create(w);
    natural.initialize(
        w,
        w.getLocalDifficulty(test.getAbsolutePos(BlockPos.ORIGIN)),
        net.minecraft.entity.SpawnReason.NATURAL,
        null);
    test.assertTrue(
        natural.getCommandTags().contains("reterra_barren_spawn"),
        "Naturally spawned wildlife is suppressed.");
    var revived = net.minecraft.entity.EntityType.SHEEP.create(w);
    revived.initialize(
        w,
        w.getLocalDifficulty(test.getAbsolutePos(BlockPos.ORIGIN)),
        net.minecraft.entity.SpawnReason.BREEDING,
        null);
    test.assertFalse(
        revived.getCommandTags().contains("reterra_barren_spawn"), "Breeding must stay available.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void reclaimedBiomesPersistAndPreserveOtherBiomeIdentities(TestContext test) {
    ServerWorld w = test.getWorld();
    BlockPos p = test.getAbsolutePos(new BlockPos(3, 2, 3));
    var m = new RestorationState.Machine(p, "restoration_core");
    m.reclaimed = true;
    m.biomeCursor = 4;
    m.biome = w.getBiome(p).getKey().orElseThrow().getValue().toString();
    int x = (p.getX() >> 4) * 16 + 8, z = (p.getZ() >> 4) * 16 + 8;
    var forest =
        w.getRegistryManager()
            .get(net.minecraft.registry.RegistryKeys.BIOME)
            .getEntry(net.minecraft.util.Identifier.ofVanilla("forest"))
            .orElseThrow();
    BlockPos forestColumn = new BlockPos((x >> 4) * 16, 64, (z >> 4) * 16);
    net.minecraft.server.command.FillBiomeCommand.fillBiome(w, forestColumn, forestColumn, forest);
    dev.reterra.world.ReclaimedBiomes.tick(w, m);
    test.assertTrue(
        m.sectors[4].biomeTransitioned, "A loaded sector must finish its biome transition.");
    var biome = w.getChunk(x >> 4, z >> 4).getBiomeForNoiseGen(x >> 2, 64 >> 2, z >> 2);
    test.assertTrue(
        biome.getKey().orElseThrow().getValue().toString().equals("reterra:reclaimed_plains"),
        "Completed regions must use a distinct reclaimed biome.");
    test.assertTrue(
        w.getChunk(x >> 4, z >> 4)
            .getBiomeForNoiseGen(forestColumn.getX() >> 2, 16, forestColumn.getZ() >> 2)
            .matchesId(net.minecraft.util.Identifier.ofVanilla("forest")),
        "A neighboring biome identity inside the same chunk must remain untouched.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void generationLeavesDeadWoodAndRemovesLivingSurface(TestContext test) {
    ServerWorld w = test.getWorld();
    BlockPos p = test.getAbsolutePos(new BlockPos(4, 2, 4));
    w.setBlockState(p, Blocks.GRASS_BLOCK.getDefaultState());
    w.setBlockState(p.up(), Blocks.DANDELION.getDefaultState());
    w.setBlockState(p.east(), Blocks.OAK_LOG.getDefaultState());
    w.setBlockState(p.east().up(), Blocks.OAK_LEAVES.getDefaultState());
    dev.reterra.world.BarrenWorld.transform(w, w.getChunk(p));
    test.assertFalse(
        w.getBlockState(p).isOf(Blocks.GRASS_BLOCK), "Generated surface must be barren.");
    test.assertTrue(
        w.getBlockState(p.up()).isAir() && w.getBlockState(p.east().up()).isAir(),
        "Generated flowers and leaves must be removed.");
    test.assertTrue(
        w.getBlockState(p.east()).isOf(Blocks.OAK_LOG),
        "Dead trees must still provide normal wood.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void realBlockPlacementIsProtected(TestContext test) {
    ServerWorld w = test.getWorld();
    BlockPos base = test.getAbsolutePos(new BlockPos(3, 2, 3));
    w.setBlockState(base, Blocks.STONE.getDefaultState());
    w.setBlockState(base.up(), Blocks.AIR.getDefaultState());
    var player = test.createMockCreativeServerPlayerInWorld();
    var hit =
        new net.minecraft.util.hit.BlockHitResult(
            net.minecraft.util.math.Vec3d.ofCenter(base),
            net.minecraft.util.math.Direction.UP,
            base,
            false);
    var placement =
        new net.minecraft.item.ItemPlacementContext(
            w, player, net.minecraft.util.Hand.MAIN_HAND, new ItemStack(Items.DIRT), hit);
    var result = ((net.minecraft.item.BlockItem) Items.DIRT).place(placement);
    test.assertTrue(result.isAccepted(), "Fixture must place a real block item.");
    var state = RestorationState.get(w);
    test.assertTrue(
        state.protectedBlocks.contains(base.up().asLong()),
        "The placement hook must protect the actual destination block.");
    state.protectedBlocks.remove(base.up().asLong());
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE, tickLimit = 200)
  public void everyResearchSiteBuildsWithUsableLoot(TestContext test) {
    ServerWorld w = test.getWorld();
    int cx = (test.getAbsolutePos(BlockPos.ORIGIN).getX() >> 4) + 16;
    int cz = (test.getAbsolutePos(BlockPos.ORIGIN).getZ() >> 4) + 16;
    for (var kind : dev.reterra.world.ResearchSites.Kind.values()) {
      int x = (cx + kind.ordinal()) * 16 + 8, z = cz * 16 + 8;
      w.getChunk(x >> 4, z >> 4);
      BlockPos surface = new BlockPos(x, 80, z);
      dev.reterra.world.ResearchSites.build(w, surface, kind);
      BlockPos chest = dev.reterra.world.ResearchSites.chestPosition(surface, kind);
      test.assertTrue(
          w.getBlockEntity(chest) instanceof net.minecraft.block.entity.ChestBlockEntity,
          "Site must contain a chest: " + kind);
      var inventory = (net.minecraft.inventory.Inventory) w.getBlockEntity(chest);
      boolean supplies = false;
      for (int i = 0; i < inventory.size(); i++)
        if (!inventory.getStack(i).isEmpty()) supplies = true;
      test.assertTrue(supplies, "Site loot table must generate resources: " + kind);
      int pouches = 0, cultures = 0, samples = 0;
      for (int i = 0; i < inventory.size(); i++) {
        var stack = inventory.getStack(i);
        if (stack.isOf(Content.RECOVERY_BUNDLE)) pouches += stack.getCount();
        if (stack.isOf(Content.CULTURE)) cultures += stack.getCount();
        if (dev.reterra.machine.MachineLogic.sample(stack)) samples += stack.getCount();
      }
      boolean seedSite =
          kind == dev.reterra.world.ResearchSites.Kind.FARMHOUSE
              || kind == dev.reterra.world.ResearchSites.Kind.SEED_VAULT;
      test.assertTrue(
          pouches == (seedSite ? 1 : 0),
          "Only farmhouses and seed vaults should contain one seed pouch.");
      test.assertTrue(
          cultures == (kind == dev.reterra.world.ResearchSites.Kind.GREENHOUSE ? 1 : 0),
          "Living cultures belong in greenhouses, not every random chest.");
      test.assertTrue(
          samples == (kind == dev.reterra.world.ResearchSites.Kind.BIOLOGICAL_ARCHIVE ? 1 : 0),
          "Each archive preserves one sample, so one chest cannot finish wildlife progression.");
      int circuits = 0;
      for (int i = 0; i < inventory.size(); i++)
        if (inventory.getStack(i).isOf(Content.FRAGMENT))
          circuits += inventory.getStack(i).getCount();
      test.assertTrue(
          circuits == (kind == dev.reterra.world.ResearchSites.Kind.RESEARCH_STATION ? 1 : 0),
          "Control circuits belong to Research Stations, separate from preserved samples.");
      test.assertFalse(
          w.getBlockState(surface).isOf(Content.CORE)
              || w.getBlockState(surface).isOf(Content.CHAMBER),
          "Ruins must not give away complete machines.");
      if (kind == dev.reterra.world.ResearchSites.Kind.GREENHOUSE)
        test.assertTrue(
            w.getBlockState(surface.add(-4, 0, 3)).isOf(Blocks.BEEHIVE),
            "Greenhouses must supply an empty hive before the first honeycomb exists.");
    }
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void joiningDoesNotGiveAnyItems(TestContext test) {
    var player = test.createMockCreativeServerPlayerInWorld();
    player.getInventory().clear();
    ReTerra.onJoin(player);
    ReTerra.onJoin(player);
    test.assertTrue(
        player.getInventory().isEmpty(), "First join and reconnect must leave inventory empty.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void seedPouchContainsOnlyOneSmallPlantingStart(TestContext test) {
    var player = test.createMockPlayer(net.minecraft.world.GameMode.SURVIVAL);
    test.assertFalse(player.isCreative(), "Seed-pouch fixture must use survival consumption.");
    player.getInventory().clear();
    player.setStackInHand(
        net.minecraft.util.Hand.MAIN_HAND, new ItemStack(Content.RECOVERY_BUNDLE));
    ReTerra.openBundle(player, player.getMainHandStack());
    int seeds = 0, mushrooms = 0, total = 0;
    for (int i = 0; i < player.getInventory().size(); i++) {
      var stack = player.getInventory().getStack(i);
      total += stack.getCount();
      if (stack.isOf(Items.WHEAT_SEEDS)) seeds += stack.getCount();
      if (stack.isOf(Items.BROWN_MUSHROOM)) mushrooms += stack.getCount();
    }
    test.assertTrue(
        seeds == 2 && mushrooms == 1 && total == 3,
        "Pouch contains exactly 2 wheat seeds and 1 mushroom; no gear, saplings or water.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void hoeCannotProduceDirtFromSterileSoil(TestContext test) {
    var w = test.getWorld();
    var pos = test.getAbsolutePos(new BlockPos(3, 2, 3));
    w.setBlockState(pos, Blocks.COARSE_DIRT.getDefaultState());
    w.setBlockState(pos.up(), Blocks.AIR.getDefaultState());
    var player = test.createMockCreativeServerPlayerInWorld();
    player.changeGameMode(net.minecraft.world.GameMode.SURVIVAL);
    player.setStackInHand(net.minecraft.util.Hand.MAIN_HAND, new ItemStack(Items.WOODEN_HOE));
    var hit =
        new net.minecraft.util.hit.BlockHitResult(
            net.minecraft.util.math.Vec3d.ofCenter(pos),
            net.minecraft.util.math.Direction.UP,
            pos,
            false);
    var context =
        new net.minecraft.item.ItemUsageContext(player, net.minecraft.util.Hand.MAIN_HAND, hit);
    var result = Items.WOODEN_HOE.useOnBlock(context);
    test.assertTrue(
        result == net.minecraft.util.ActionResult.FAIL
            && w.getBlockState(pos).isOf(Blocks.COARSE_DIRT),
        "Hoe must not bypass restoration.");
    test.assertTrue(
        player.getMainHandStack().getDamage() == 0, "Blocked tilling must not damage the hoe.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void generationAlsoSterilizesBuriedDirt(TestContext test) {
    var w = test.getWorld();
    var pos = test.getAbsolutePos(new BlockPos(4, 6, 4));
    w.setBlockState(pos, Blocks.COARSE_DIRT.getDefaultState());
    w.setBlockState(pos.down(), Blocks.DIRT.getDefaultState());
    w.setBlockState(pos.down(3), Blocks.ROOTED_DIRT.getDefaultState());
    dev.reterra.world.BarrenWorld.transform(w, w.getChunk(pos));
    test.assertFalse(
        w.getBlockState(pos.down()).isOf(Blocks.DIRT),
        "There must not be a free fertile second layer.");
    test.assertTrue(
        w.getBlockState(pos.down(3)).isOf(Blocks.COARSE_DIRT)
            || w.getBlockState(pos.down(3)).isOf(Blocks.GRAVEL),
        "Deep rooted dirt must also be sterile.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void machineSlotsPersistAndShiftClickCannotDuplicateOrInsertOutput(TestContext test) {
    var w = test.getWorld();
    var pos = test.getAbsolutePos(new BlockPos(3, 2, 3));
    assemble(w, pos);
    var state = RestorationState.get(w);
    var m = new RestorationState.Machine(pos, "soil_reclaimer");
    m.dirty = state::markDirty;
    state.machines.put(pos.asLong(), m);
    var player = test.createMockCreativeServerPlayerInWorld();
    player.refreshPositionAndAngles(pos.getX() + 1.5, pos.getY(), pos.getZ() + 1.5, 0, 0);
    player.getInventory().clear();
    var handler =
        new dev.reterra.screen.MachineScreenHandler(1, player.getInventory(), w, m, false);
    player.getInventory().setStack(0, new ItemStack(Items.DIRT, 5));
    test.assertTrue(
        handler.quickMove(player, 35).isEmpty(), "Dirt must not be inserted as fuel or output.");
    player.getInventory().setStack(0, new ItemStack(Items.GRAVEL, 5));
    handler.quickMove(player, 35);
    test.assertTrue(
        m.getStack(3).isOf(Items.GRAVEL)
            && m.getStack(3).getCount() == 5
            && player.getInventory().getStack(0).isEmpty(),
        "Shift-click must transfer gravel exactly once.");
    test.assertFalse(
        handler.slots.get(6).canInsert(new ItemStack(Items.DIRT)),
        "Output slot is extraction-only.");
    var saved = state.writeNbt(new NbtCompound(), w.getRegistryManager());
    var restored = RestorationState.fromNbt(saved, w.getRegistryManager());
    test.assertTrue(
        restored.machines.get(pos.asLong()).getStack(3).getCount() == 5,
        "Inserted items must survive saving and reload.");
    m.setStack(6, new ItemStack(Items.DIRT, 4));
    handler.quickMove(player, 6);
    test.assertTrue(m.getStack(6).isEmpty(), "Shift-click extracts the output once.");
    int dirt = 0;
    for (int i = 0; i < player.getInventory().size(); i++)
      if (player.getInventory().getStack(i).isOf(Items.DIRT))
        dirt += player.getInventory().getStack(i).getCount();
    test.assertTrue(dirt == 4, "No duplicate items after output extraction.");
    boolean before = m.production;
    player.refreshPositionAndAngles(pos.getX() + 100.5, pos.getY(), pos.getZ() + 0.5, 0, 0);
    test.assertFalse(
        handler.onButtonClick(player, 0),
        "A forged button packet must not operate a distant machine.");
    test.assertTrue(m.production == before, "Rejected remote control must preserve machine mode.");
    state.machines.remove(pos.asLong());
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void brokenMachineDropsStoredItemsAndRemovesItsRecord(TestContext test) {
    var w = test.getWorld();
    var pos = test.getAbsolutePos(new BlockPos(3, 2, 3));
    assemble(w, pos);
    var state = RestorationState.get(w);
    var m = new RestorationState.Machine(pos, "soil_reclaimer");
    m.setStack(0, new ItemStack(Content.COMPOST, 3));
    state.machines.put(pos.asLong(), m);
    w.setBlockState(pos, Blocks.AIR.getDefaultState());
    test.assertFalse(
        state.machines.containsKey(pos.asLong()),
        "Destroyed machines must not retain live inventories.");
    int count =
        w
            .getEntitiesByClass(
                net.minecraft.entity.ItemEntity.class,
                new net.minecraft.util.math.Box(pos).expand(2),
                item -> item.getStack().isOf(Content.COMPOST))
            .stream()
            .mapToInt(item -> item.getStack().getCount())
            .sum();
    test.assertTrue(count == 3, "Stored supplies must be dropped exactly once.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE, tickLimit = 60)
  public void idleCoreDoesNotBurnCoalOrCompost(TestContext test) {
    var w = test.getWorld();
    var pos = test.getAbsolutePos(new BlockPos(3, 2, 3));
    w.setBlockState(pos, Content.CORE.getDefaultState());
    w.setBlockState(pos.down(), Blocks.FURNACE.getDefaultState());
    for (var direction : net.minecraft.util.math.Direction.Type.HORIZONTAL)
      w.setBlockState(pos.offset(direction), Blocks.POLISHED_ANDESITE.getDefaultState());
    w.setBlockState(pos.north(2), Blocks.WATER_CAULDRON.getDefaultState());
    var state = RestorationState.get(w);
    var m = new RestorationState.Machine(pos, "restoration_core");
    m.registered = false;
    m.biome = "minecraft:the_void";
    m.compost = 256;
    m.fuel = 2048;
    m.water = 2048;
    state.machines.put(pos.asLong(), m);
    test.runAtTick(
        25,
        () -> {
          test.assertTrue(
              m.compost == 256 && m.fuel == 2048 && m.water == 2048,
              "Survey-only ticks must consume no work credits.");
          state.machines.remove(pos.asLong());
          test.complete();
        });
  }

  private static void assemble(ServerWorld w, BlockPos p) {
    w.setBlockState(p, Content.RECLAIMER.getDefaultState());
    w.setBlockState(p.down(), Blocks.FURNACE.getDefaultState());
    w.setBlockState(p.north(), Blocks.BARREL.getDefaultState());
    w.setBlockState(
        p.south(), Blocks.WATER_CAULDRON.getDefaultState().with(LeveledCauldronBlock.LEVEL, 3));
    if (Multiblocks.missing(w, p) != null)
      throw new AssertionError("Valid reclaimer multiblock was rejected.");
  }

  @GameTest(templateName = EMPTY_STRUCTURE)
  public void healthyTrialCannotBeSkippedByUnloadingAndProgressPersists(TestContext test) {
    var m = new RestorationState.Machine(test.getAbsolutePos(BlockPos.ORIGIN), "restoration_core");
    for (int tick = 20; tick <= 3620; tick += 20)
      dev.reterra.machine.RestorationEngine.updateStability(m, true, tick);
    test.assertTrue(
        m.stableSeconds == 180, "Three minutes of healthy loaded time completes the trial.");
    m.stableSeconds = 170;
    dev.reterra.machine.RestorationEngine.updateStability(m, false, 3640);
    test.assertTrue(
        m.stableSeconds == 170, "A momentary habitat loss must preserve earned progress.");
    dev.reterra.machine.RestorationEngine.updateStability(m, true, 3660);
    dev.reterra.machine.RestorationEngine.updateStability(m, true, 3680);
    test.assertTrue(
        m.stableSeconds == 173, "Healthy loaded time must resume from existing progress.");
    dev.reterra.machine.RestorationEngine.updateStability(m, true, 8000);
    test.assertTrue(
        m.stableSeconds == 173,
        "Time spent unloaded must pause, without completing or erasing progress.");
    for (int tick = 8020; tick <= 8120; tick += 20)
      dev.reterra.machine.RestorationEngine.updateStability(m, false, tick);
    test.assertTrue(
        m.stableSeconds == 172,
        "A deteriorating loaded habitat loses one second per five observed seconds.");
    m.stableSeconds = 73;
    m.rewildCursor = 1900;
    var state = new RestorationState();
    state.machines.put(m.pos.asLong(), m);
    var restored =
        RestorationState.fromNbt(
            state.writeNbt(new NbtCompound(), test.getWorld().getRegistryManager()),
            test.getWorld().getRegistryManager());
    var copy = restored.machines.get(m.pos.asLong());
    test.assertTrue(
        copy.stableSeconds == 73 && copy.rewildCursor == 1900,
        "Trial and passive succession progress must survive saves.");
    test.complete();
  }

  @GameTest(templateName = EMPTY_STRUCTURE, tickLimit = 120)
  public void completedRegionHealsScarsAndRegrowsOnlyUnprotectedTrunks(TestContext test) {
    ServerWorld w = test.getWorld();
    w.setTimeOfDay(6000);
    int cx = (test.getAbsolutePos(BlockPos.ORIGIN).getX() >> 4) + 35;
    int cz = (test.getAbsolutePos(BlockPos.ORIGIN).getZ() >> 4) + 35;
    w.setChunkForced(cx, cz, true);
    w.getChunk(cx, cz);
    BlockPos origin = new BlockPos(cx * 16, 180, cz * 16);
    var m = new RestorationState.Machine(origin.add(8, 1, 8), "restoration_core");
    m.reclaimed = true;
    m.biome = w.getBiome(origin).getKey().orElseThrow().getValue().toString();
    var state = new RestorationState();
    for (int x = 0; x < 16; x++)
      for (int z = 0; z < 16; z++) {
        w.setBlockState(origin.add(x, 0, z), Blocks.GRASS_BLOCK.getDefaultState());
        for (int y = 1; y < 9; y++)
          w.setBlockState(origin.add(x, y, z), Blocks.AIR.getDefaultState());
      }
    BlockPos scar = origin.add(2, 0, 2), protectedSoil = origin.add(3, 0, 3);
    w.setBlockState(scar.down(), Blocks.STONE.getDefaultState());
    w.setBlockState(protectedSoil.down(), Blocks.STONE.getDefaultState());
    w.setBlockState(scar, Blocks.GRAVEL.getDefaultState());
    w.setBlockState(protectedSoil, Blocks.GRAVEL.getDefaultState());
    state.protectedBlocks.add(protectedSoil.asLong());
    BlockPos trunk = origin.add(5, 1, 5), protectedTrunk = origin.add(11, 1, 11);
    for (int y = 0; y < 4; y++) {
      w.setBlockState(trunk.up(y), Blocks.OAK_LOG.getDefaultState());
      w.setBlockState(protectedTrunk.up(y), Blocks.OAK_LOG.getDefaultState());
      state.protectedBlocks.add(protectedTrunk.up(y).asLong());
    }
    test.runAtTick(
        30,
        () -> {
          for (int i = 0; i < 350; i++) dev.reterra.machine.RestorationEngine.rewild(w, state, m);
          test.assertTrue(
              w.getBlockState(scar).isOf(Blocks.DIRT)
                  || w.getBlockState(scar).isOf(Blocks.GRASS_BLOCK),
              "A completed region must reclaim sterile scar soil.");
        });
    // Lighting is asynchronous. Give terrain and crown changes real ticks before the grass pass.
    test.runAtTick(
        60,
        () -> {
          for (int i = 0; i < 350; i++) dev.reterra.machine.RestorationEngine.rewild(w, state, m);
          test.assertTrue(
              w.getBlockState(scar).isOf(Blocks.GRASS_BLOCK),
              "Even scar gravel should heal after completion: "
                  + w.getBlockState(scar)
                  + ", loaded="
                  + dev.reterra.machine.RestorationEngine.loaded(w, scar)
                  + ", ground="
                  + dev.reterra.machine.RestorationEngine.ground(w, scar.getX(), scar.getZ())
                  + ", biome="
                  + w.getBiome(scar).getKey()
                  + ", expected="
                  + m.biome
                  + ", light="
                  + w.getLightLevel(scar.up())
                  + ", day="
                  + w.getTimeOfDay());
          test.assertTrue(
              w.getBlockState(protectedSoil).isOf(Blocks.GRAVEL),
              "Player gravel must survive succession.");
          test.assertTrue(
              w.getBlockState(trunk.west().up(3)).isOf(Blocks.OAK_LEAVES),
              "Natural dead trunks should regrow a crown.");
          test.assertTrue(
              w.getBlockState(protectedTrunk.up(4)).isAir(),
              "Player log pillars must not grow leaves.");
          test.assertTrue(
              m.compost == 0 && m.fuel == 0 && m.water == 0,
              "Recovered ecosystems need no machine supplies.");
          w.setChunkForced(cx, cz, false);
          test.complete();
        });
  }

  @GameTest(templateName = EMPTY_STRUCTURE, tickLimit = 160)
  public void locateCommandFindsAnActualArchiveAndSupportsVanillaSyntax(TestContext test) {
    ServerWorld w = test.getWorld();
    var from = test.getAbsolutePos(BlockPos.ORIGIN).add(3000, 0, 3000);
    var kind = dev.reterra.world.ResearchSites.Kind.BIOLOGICAL_ARCHIVE;
    BlockPos candidate =
        dev.reterra.world.SiteLocator.candidates(w.getSeed(), from, kind).getFirst();
    w.getChunk(candidate.getX() >> 4, candidate.getZ() >> 4);
    BlockPos surface =
        candidate.withY(
            w.getTopY(
                    net.minecraft.world.Heightmap.Type.WORLD_SURFACE,
                    candidate.getX(),
                    candidate.getZ())
                + 1);
    dev.reterra.world.ResearchSites.build(w, surface, kind);
    BlockPos chest = dev.reterra.world.ResearchSites.chestPosition(surface, kind);
    test.assertTrue(
        chest.equals(dev.reterra.world.SiteLocator.findChest(w, candidate, kind)),
        "Locator must find the real chest, including its actual elevation.");
    var output = new StringBuilder();
    var sink =
        new net.minecraft.server.command.CommandOutput() {
          public void sendMessage(net.minecraft.text.Text text) {
            output.append(text.getString()).append('\n');
          }

          public boolean shouldReceiveFeedback() {
            return true;
          }

          public boolean shouldTrackOutput() {
            return true;
          }

          public boolean shouldBroadcastConsoleToOps() {
            return false;
          }
        };
    var source =
        w.getServer()
            .getCommandSource()
            .withWorld(w)
            .withPosition(net.minecraft.util.math.Vec3d.ofCenter(surface))
            .withOutput(sink);
    var dispatcher = w.getServer().getCommandManager().getDispatcher();
    for (String command :
        new String[] {
          "locate reterra biological_archive",
          "locate structure reterra:biological_archive",
          "reterra locate biological_archive"
        })
      test.assertTrue(
          dispatcher.parse(command, source).getReader().getRemaining().isEmpty(),
          "Command must parse: " + command);
    dev.reterra.world.SiteLocator.clear();
    w.getServer()
        .getCommandManager()
        .executeWithPrefix(source, "locate structure reterra:biological_archive");
    test.runAtTick(
        80,
        () -> {
          test.assertTrue(
              output
                  .toString()
                  .contains(
                      "found at [" + chest.getX() + ", " + chest.getY() + ", " + chest.getZ()),
              "Asynchronous command must report an existing Archive, not an unchecked prediction: "
                  + output);
          dev.reterra.world.SiteLocator.clear();
          test.complete();
        });
  }
}
