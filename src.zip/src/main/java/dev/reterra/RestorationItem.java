package dev.reterra;

import java.util.List;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class RestorationItem extends Item {
  private final String key;

  public RestorationItem(String key, Settings settings) {
    super(settings);
    this.key = key;
  }

  @Override
  public void appendTooltip(
      ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
    String hint = Text.translatable("hint.reterra." + key).getString();
    StringBuilder line = new StringBuilder();
    for (String word : hint.split(" ")) {
      if (line.length() + word.length() > 48) {
        tooltip.add(Text.literal(line.toString()).formatted(Formatting.GRAY));
        line.setLength(0);
      }
      if (!line.isEmpty()) line.append(' ');
      line.append(word);
    }
    if (!line.isEmpty()) tooltip.add(Text.literal(line.toString()).formatted(Formatting.GRAY));
  }
}
