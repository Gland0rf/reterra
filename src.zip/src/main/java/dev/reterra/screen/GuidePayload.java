package dev.reterra.screen;

import dev.reterra.Content;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;

public record GuidePayload(
    int chapter, int completed, String objective, String checklist, boolean open)
    implements CustomPayload {
  public static final Id<GuidePayload> ID = new Id<>(Content.id("field_guide"));
  public static final PacketCodec<RegistryByteBuf, GuidePayload> CODEC =
      new PacketCodec<>() {
        @Override
        public GuidePayload decode(RegistryByteBuf buf) {
          return new GuidePayload(
              buf.readVarInt(),
              buf.readVarInt(),
              buf.readString(1024),
              buf.readString(2048),
              buf.readBoolean());
        }

        @Override
        public void encode(RegistryByteBuf buf, GuidePayload value) {
          buf.writeVarInt(value.chapter);
          buf.writeVarInt(value.completed);
          buf.writeString(value.objective, 1024);
          buf.writeString(value.checklist, 2048);
          buf.writeBoolean(value.open);
        }
      };

  @Override
  public Id<? extends CustomPayload> getId() {
    return ID;
  }
}
