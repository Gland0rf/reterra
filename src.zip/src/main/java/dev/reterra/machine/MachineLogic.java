package dev.reterra.machine;

import dev.reterra.Content;
import dev.reterra.Journal;
import dev.reterra.ecology.Ecology;
import dev.reterra.state.RestorationState;
import dev.reterra.state.RestorationState.Machine;
import java.util.List;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

public final class MachineLogic {
  private MachineLogic() {}

  public static final List<String> KINDS =
      List.of(
          "soil_reclaimer",
          "restoration_core",
          "water_restorer",
          "revival_chamber",
          "heart_of_the_world");

  public enum Status {
    READY,
    ASSEMBLY,
    REGISTER,
    OVERLAP,
    PAUSED,
    COMPOST,
    FUEL,
    WATER,
    MATERIAL,
    OUTPUT,
    HABITAT,
    SAMPLE,
    FOOD,
    NUTRIENTS,
    NO_SPACE,
    REVIVED,
    RECLAIMED,
    OBJECTIVES,
    COMPLETE,
    CULTURE,
    INCUBATING,
    POPULATION,
    STABILIZING
  }

  public static int kind(Machine m) {
    return Math.max(0, KINDS.indexOf(m.kind));
  }

  public static boolean feedstock(ItemStack s) {
    return s.isOf(Items.GRAVEL) || s.isOf(Items.COARSE_DIRT);
  }

  public static boolean sample(ItemStack s) {
    return s.isOf(Content.SHEEP_SAMPLE)
        || s.isOf(Content.COW_SAMPLE)
        || s.isOf(Content.CHICKEN_SAMPLE)
        || s.isOf(Content.BEE_SAMPLE);
  }

  public static boolean accepts(int kind, int slot, ItemStack s) {
    return switch (slot) {
      case 0 ->
          kind == 2 ? s.isOf(Content.FILTER) : (kind == 0 || kind == 1) && s.isOf(Content.COMPOST);
      case 1 ->
          kind < 3 && (s.isOf(Items.COAL) || s.isOf(Items.CHARCOAL) || s.isOf(Content.NUTRIENTS));
      case 2 -> kind < 4 && s.isOf(Items.WATER_BUCKET);
      case 3 ->
          switch (kind) {
            case 0 -> feedstock(s);
            case 1 -> s.isOf(Content.CULTURE);
            case 2 -> s.isOf(Items.BUCKET);
            case 3 -> sample(s);
            default -> false;
          };
      case 4 ->
          kind == 3
              && (s.isOf(Items.WHEAT)
                  || s.isOf(Items.WHEAT_SEEDS)
                  || s.isIn(net.minecraft.registry.tag.ItemTags.FLOWERS));
      case 5 -> kind == 3 && s.isOf(Content.NUTRIENTS);
      default -> false;
    };
  }

  public static boolean visible(int kind, int slot) {
    return switch (slot) {
      case 0, 1 -> kind < 3;
      case 2, 3 -> kind < 4;
      case 4, 5 -> kind == 3;
      case 6 -> kind == 0 || kind == 2;
      case 7 -> false;
      default -> false;
    };
  }

  public static boolean room(Machine m, int slot, Item item, int count) {
    ItemStack old = m.getStack(slot);
    return old.isEmpty()
        ? count <= item.getMaxCount()
        : old.isOf(item) && old.getCount() + count <= old.getMaxCount();
  }

  public static void output(Machine m, int slot, Item item, int count) {
    if (m.getStack(slot).isEmpty()) m.setStack(slot, new ItemStack(item, count));
    else m.getStack(slot).increment(count);
    m.markDirty();
  }

  public static void stock(Machine m) {
    int kind = kind(m);
    if (kind < 3) {
      if (m.compost < 1 && accepts(kind, 0, m.getStack(0))) {
        m.removeStack(0, 1);
        m.compost += kind == 2 ? Balance.FILTER_WORK : Balance.COMPOST_WORK;
      }
      if (m.fuel < (kind == 2 ? 4 : 1) && accepts(kind, 1, m.getStack(1))) {
        boolean bio = m.getStack(1).isOf(Content.NUTRIENTS);
        m.removeStack(1, 1);
        m.fuel += bio ? Balance.BIOFUEL_WORK : Balance.COAL_WORK;
      }
    }
    if (kind < 4
        && m.water < (kind == 3 ? 16 : kind == 2 ? Balance.WATER_WORK : 1)
        && m.getStack(2).isOf(Items.WATER_BUCKET)) {
      m.setStack(2, new ItemStack(Items.BUCKET));
      m.water += Balance.WATER_WORK;
    }
    if (kind == 1 && m.culture < 1 && m.getStack(3).isOf(Content.CULTURE)) {
      m.removeStack(3, 1);
      m.culture += Balance.CULTURE_WORK;
    }
  }

  public static void stock(ServerWorld world, Machine m) {
    int compost = m.compost, fuel = m.fuel, culture = m.culture;
    stock(m);
    if (!RestorationState.get(world).completed.isEmpty() && kind(m) < 2) {
      m.compost += Math.max(0, m.compost - compost) / 4;
      m.fuel += Math.max(0, m.fuel - fuel) / 4;
      m.culture += Math.max(0, m.culture - culture) / 4;
    }
  }

  public static boolean register(ServerWorld w, Machine m) {
    var state = RestorationState.get(w);
    for (Machine other : state.machines.values())
      if (other != m
          && other.kind.equals("restoration_core")
          && other.registered
          && Ecology.overlaps(
              m.pos.getX() >> 4, m.pos.getZ() >> 4, other.pos.getX() >> 4, other.pos.getZ() >> 4)) {
        m.feedback = Status.OVERLAP.ordinal();
        return false;
      }
    for (Machine other : state.reclaimedRegions.values())
      if (Ecology.overlaps(
          m.pos.getX() >> 4, m.pos.getZ() >> 4, other.pos.getX() >> 4, other.pos.getZ() >> 4)) {
        m.feedback = Status.OVERLAP.ordinal();
        return false;
      }
    m.registered = true;
    m.feedback = 0;
    m.markDirty();
    return true;
  }

  public static Status status(ServerWorld w, Machine m) {
    if (m.reclaimed) return Status.RECLAIMED;
    if (Multiblocks.issue(w, m.pos, m.kind) > 0) return Status.ASSEMBLY;
    if (m.paused) return Status.PAUSED;
    int kind = kind(m);
    if (kind == 4)
      return RestorationState.get(w).heartActivated ? Status.COMPLETE : Status.OBJECTIVES;
    if (kind == 1 && !m.registered)
      return m.feedback == Status.OVERLAP.ordinal() ? Status.OVERLAP : Status.REGISTER;
    if (kind == 3) {
      var status = habitatStatus(w, m);
      return status == Status.READY && !m.pendingSpecies.isEmpty() ? Status.INCUBATING : status;
    }
    if (kind == 1
        && java.util.Arrays.stream(m.sectors).allMatch(s -> s.surveyed)
        && m.survey(RestorationEngine.animalSpecies(w, m)).stage(m.family)
            == Ecology.Stage.RECLAIMED) return Status.STABILIZING;
    int soilTarget = Ecology.goals(m.family).soil();
    if (kind == 1
        && m.survey(0).soilPercent() >= soilTarget
        && m.culture < 1
        && m.getStack(3).isEmpty()) return Status.CULTURE;
    if (m.compost < 1
        && m.getStack(0).isEmpty()
        && (kind != 1 || m.survey(0).soilPercent() < soilTarget)) return Status.COMPOST;
    if (m.fuel < 1 && m.getStack(1).isEmpty()) return Status.FUEL;
    if (m.water < 1 && !m.getStack(2).isOf(Items.WATER_BUCKET)) return Status.WATER;
    if (kind == 0 && m.production && !feedstock(m.getStack(3))) {
      if (!(w.getBlockEntity(Multiblocks.barrel(w, m.pos))
              instanceof net.minecraft.inventory.Inventory inv)
          || !containsGravel(inv)) return Status.MATERIAL;
    }
    if (kind == 2) return Status.READY;
    if ((kind == 0 || kind == 2) && !room(m, 6, kind == 0 ? Items.DIRT : Items.WATER_BUCKET, 1))
      return Status.OUTPUT;
    return Status.READY;
  }

  private static boolean containsGravel(net.minecraft.inventory.Inventory inv) {
    for (int i = 0; i < inv.size(); i++) if (feedstock(inv.getStack(i))) return true;
    return false;
  }

  public static Status habitatStatus(ServerWorld w, Machine chamber) {
    Machine core = RestorationEngine.regionAt(RestorationState.get(w), chamber.pos);
    if (core == null) return Status.REGISTER;
    var survey = core.survey(RestorationEngine.animalCount(w, core));
    if (!survey.habitat(core.family) || survey.trees() < 1 || survey.flowers() < 1)
      return Status.HABITAT;
    if (RestorationEngine.animalCount(w, core) >= 16) return Status.POPULATION;
    if (!sample(chamber.getStack(3))) return Status.SAMPLE;
    if (!foodMatches(chamber.getStack(3), chamber.getStack(4))
        || chamber.getStack(4).getCount() < foodCount(chamber.getStack(3))) return Status.FOOD;
    if (!chamber.getStack(5).isOf(Content.NUTRIENTS) || chamber.getStack(5).getCount() < 1)
      return Status.NUTRIENTS;
    if (chamber.water < 16 && !chamber.getStack(2).isOf(Items.WATER_BUCKET)) return Status.WATER;
    return Status.READY;
  }

  public static Item food(ItemStack sample) {
    return sample.isOf(Content.BEE_SAMPLE)
        ? Items.DANDELION
        : sample.isOf(Content.CHICKEN_SAMPLE) ? Items.WHEAT_SEEDS : Items.WHEAT;
  }

  public static int foodCount(ItemStack sample) {
    return sample.isOf(Content.BEE_SAMPLE) ? 2 : 4;
  }

  public static boolean foodMatches(ItemStack sample, ItemStack food) {
    return sample.isOf(Content.BEE_SAMPLE)
        ? food.isIn(net.minecraft.registry.tag.ItemTags.FLOWERS)
        : food.isOf(food(sample));
  }

  public static void action(ServerWorld w, Machine m, ServerPlayerEntity player, int button) {
    if (button == 3 && m.kind.equals("revival_chamber")) {
      m.pendingSpecies = "";
      m.revivalTicks = 0;
      m.feedback = 0;
      m.markDirty();
      return;
    }
    if (button == 0 && m.kind.equals("soil_reclaimer")) {
      m.production = !m.production;
      m.markDirty();
      return;
    }
    if (button == 0 && m.kind.equals("water_restorer")) {
      m.riverMode = !m.riverMode;
      m.markDirty();
      return;
    }
    if (button == 2) {
      m.paused = !m.paused;
      m.markDirty();
      return;
    }
    if (button != 1 || Multiblocks.issue(w, m.pos, m.kind) > 0 || m.reclaimed || m.paused) return;
    m.feedback = 0;
    switch (m.kind) {
      case "restoration_core" -> {
        if (register(w, m)) Journal.grant(player, "greener_world");
      }
      case "water_restorer" -> {
        stock(m);
        water(m);
      }
      case "revival_chamber" -> revive(w, m, player);
      case "heart_of_the_world" -> {
        var state = RestorationState.get(w);
        if (state.completed.size() == 4 && !state.heartActivated) {
          state.heartActivated = true;
          state.heartPos = m.pos;
          state.heartTicks = 0;
          state.heartCursor = (128 + (m.pos.getZ() & 15)) * 272 + 128 + (m.pos.getX() & 15);
          MachineBlock.updateVisual(w, m);
          w.playSound(
              null,
              m.pos,
              net.minecraft.sound.SoundEvents.UI_TOAST_CHALLENGE_COMPLETE,
              net.minecraft.sound.SoundCategory.BLOCKS,
              1,
              .8f);
          state.markDirty();
          w.getServer()
              .getPlayerManager()
              .getPlayerList()
              .forEach(p -> Journal.grant(p, "new_beginning"));
          w.spawnParticles(
              net.minecraft.particle.ParticleTypes.HAPPY_VILLAGER,
              m.pos.getX() + 0.5,
              m.pos.getY() + 1.2,
              m.pos.getZ() + 0.5,
              40,
              1,
              1,
              1,
              0.05);
        }
      }
    }
  }

  public static void water(Machine m) {
    if (m.paused
        || m.compost < 1
        || m.fuel < 4
        || m.water < Balance.WATER_WORK
        || !m.getStack(3).isOf(Items.BUCKET)
        || !room(m, 6, Items.WATER_BUCKET, 1)) return;
    m.removeStack(3, 1);
    output(m, 6, Items.WATER_BUCKET, 1);
    m.compost--;
    m.fuel -= 4;
    m.water -= Balance.WATER_WORK;
    m.markDirty();
  }

  private static void revive(ServerWorld w, Machine m, ServerPlayerEntity p) {
    if (!m.pendingSpecies.isEmpty()) return;
    stock(m);
    if (habitatStatus(w, m) != Status.READY) return;
    m.pendingSpecies = Registries.ITEM.getId(m.getStack(3).getItem()).getPath();
    m.revivalTicks = 0;
    m.feedback = Status.INCUBATING.ordinal();
    m.markDirty();
  }

  public static void revivalTick(ServerWorld w, Machine m) {
    if (m.pendingSpecies.isEmpty() || habitatStatus(w, m) != Status.READY) return;
    m.revivalTicks = Math.min(Balance.REVIVAL_TICKS, m.revivalTicks + 5);
    double angle = m.revivalTicks * 0.12;
    for (int i = 0; i < 2; i++) {
      double a = angle + i * Math.PI;
      w.spawnParticles(
          net.minecraft.particle.ParticleTypes.END_ROD,
          m.pos.getX() + .5 + Math.cos(a) * .65,
          m.pos.getY() + .3 + m.revivalTicks % 40 / 35.0,
          m.pos.getZ() + .5 + Math.sin(a) * .65,
          1,
          0,
          .02,
          0,
          .005);
    }
    if (m.revivalTicks < Balance.REVIVAL_TICKS && m.revivalTicks % 40 == 0)
      w.playSound(
          null,
          m.pos,
          net.minecraft.sound.SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME,
          net.minecraft.sound.SoundCategory.BLOCKS,
          .3f,
          .8f + m.revivalTicks / 600f);
    if (m.revivalTicks < Balance.REVIVAL_TICKS) return;
    var state = RestorationState.get(w);
    Machine core = RestorationEngine.regionAt(state, m.pos);
    if (RestorationEngine.animalCount(w, core) >= 16) return;
    ItemStack sample = m.getStack(3);
    EntityType<? extends AnimalEntity> type =
        sample.isOf(Content.BEE_SAMPLE)
            ? EntityType.BEE
            : sample.isOf(Content.CHICKEN_SAMPLE)
                ? EntityType.CHICKEN
                : sample.isOf(Content.COW_SAMPLE) ? EntityType.COW : EntityType.SHEEP;
    if (RestorationEngine.spawnPair(w, core, type, m.pos) == 0) {
      m.feedback = Status.NO_SPACE.ordinal();
      return;
    }
    int foodCost = foodCount(sample);
    m.removeStack(3, 1);
    m.removeStack(4, foodCost);
    m.removeStack(5, 1);
    m.water -= 16;
    m.pendingSpecies = "";
    m.revivalTicks = 0;
    core.restoredSpecies.add(Registries.ENTITY_TYPE.getId(type).toString());
    m.feedback = Status.REVIVED.ordinal();
    w.playSound(
        null,
        m.pos,
        net.minecraft.sound.SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP,
        net.minecraft.sound.SoundCategory.BLOCKS,
        .5f,
        1.1f);
    state.markDirty();
    w.getPlayers().stream()
        .filter(p -> RestorationEngine.bounds(core).contains(p.getPos()))
        .forEach(p -> Journal.grant(p, "natures_return"));
  }

  public static void pump(ServerWorld w, Machine pump) {
    if (pump.water < 32 && pump.fuel > 0 && pump.compost > 0) {
      boolean source = false;
      for (int dx = -2; dx <= 2 && !source; dx++)
        for (int dz = -2; dz <= 2 && !source; dz++)
          for (int dy = -1; dy <= 0; dy++) {
            var p = pump.pos.add(dx, dy, dz);
            if (RestorationEngine.loaded(w, p)
                && w.getBlockState(p).isOf(net.minecraft.block.Blocks.WATER)
                && w.getFluidState(p).isStill()) {
              source = true;
              break;
            }
          }
      if (source) pump.water += Balance.WATER_WORK;
    }
    // A full intake cauldron replenishes the tank; manual buckets work as well.
    if (pump.water < 32) {
      for (var direction : net.minecraft.util.math.Direction.Type.HORIZONTAL) {
        var pos = pump.pos.offset(direction);
        var cauldron = w.getBlockState(pos);
        if (cauldron.isOf(net.minecraft.block.Blocks.WATER_CAULDRON)
            && cauldron.get(net.minecraft.block.LeveledCauldronBlock.LEVEL) == 3) {
          pump.water += Balance.WATER_WORK;
          w.setBlockState(pos, cauldron.with(net.minecraft.block.LeveledCauldronBlock.LEVEL, 1));
          break;
        }
      }
    }
    if (pump.water < 1 || pump.fuel < 1 || pump.compost < 1) return;
    if (pump.riverMode) {
      dev.reterra.world.RiverRecovery.tick(w, pump);
      return;
    }
    for (Machine other : RestorationState.get(w).machines.values()) {
      if (other == pump
          || other.reclaimed
          || other.kind.equals("water_restorer")
          || other.kind.equals("heart_of_the_world")
          || other.water >= 32
          || other.pos.getSquaredDistance(pump.pos) > 64
          || !RestorationEngine.loaded(w, other.pos)) continue;
      int amount = Math.min(32, pump.water);
      other.water += amount;
      pump.water -= amount;
      pump.fuel--;
      pump.compost--;
      other.markDirty();
      break;
    }
    water(pump);
    pump.markDirty();
  }
}
