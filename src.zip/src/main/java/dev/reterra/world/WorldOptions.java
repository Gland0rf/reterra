package dev.reterra.world;

import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;

/** Per-save world-generation option, also exposed in the new-world Game Rules menu. */
public final class WorldOptions {
  public static final GameRules.Key<GameRules.BooleanRule> BARREN =
      GameRuleRegistry.register(
          "reterraBarrenWorld",
          GameRules.Category.UPDATES,
          GameRuleFactory.createBooleanRule(true));

  private WorldOptions() {}

  public static boolean barren(World world) {
    return world.getGameRules().getBoolean(BARREN);
  }

  public static void initialize() {}
}
