package dev.reterra.world;

import dev.reterra.machine.RestorationEngine;
import dev.reterra.state.RestorationState;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

/** Shared finale and optional survey boundaries; both operate only in loaded terrain. */
public final class WorldRecovery {
  private WorldRecovery() {}

  public static void tick(ServerWorld world, RestorationState state) {
    for (var player : world.getPlayers())
      if (state.boundaryViewers.contains(player.getUuid())) {
        var core = RestorationEngine.regionAt(state, player.getBlockPos());
        if (core == null) continue;
        int x = ((core.pos.getX() >> 4) - 1) * 16, z = ((core.pos.getZ() >> 4) - 1) * 16;
        for (int offset = 0; offset <= 48; offset += 4) {
          marker(world, player, x + offset, z);
          marker(world, player, x + offset, z + 47);
          marker(world, player, x, z + offset);
          marker(world, player, x + 47, z + offset);
        }
      }
    if (state.heartActivated && state.heartPos == null)
      state.machines.values().stream()
          .filter(m -> m.kind.equals("heart_of_the_world"))
          .findFirst()
          .ifPresent(m -> state.heartPos = m.pos);
    if (!state.heartActivated
        || state.heartPos == null
        || !RestorationEngine.loaded(world, state.heartPos)) return;
    state.heartTicks = Math.min(1200, state.heartTicks + 20);
    var heart = new RestorationState.Machine(state.heartPos, "heart_of_the_world");
    heart.spreadRadius = 8;
    heart.rewildCursor = state.heartCursor;
    for (int i = 0; i < 4; i++) RestorationEngine.rewild(world, state, heart);
    state.heartCursor = heart.rewildCursor;
    double radius = state.heartTicks <= 240 ? state.heartTicks / 10.0 : 2;
    for (int i = 0; i < 24; i++) {
      double angle = i * Math.PI / 12 + world.getTime() * .02;
      world.spawnParticles(
          ParticleTypes.END_ROD,
          state.heartPos.getX() + .5 + Math.cos(angle) * radius,
          state.heartPos.getY() + 1 + Math.sin(angle * 2) * .4,
          state.heartPos.getZ() + .5 + Math.sin(angle) * radius,
          1,
          0,
          .05,
          0,
          .01);
    }
    state.markDirty();
  }

  private static void marker(
      ServerWorld world, net.minecraft.server.network.ServerPlayerEntity player, int x, int z) {
    BlockPos ground = RestorationEngine.ground(world, x, z);
    if (ground != null)
      world.spawnParticles(
          player,
          ParticleTypes.COMPOSTER,
          true,
          x + .5,
          ground.getY() + 1.15,
          z + .5,
          1,
          0,
          .2,
          0,
          0);
  }
}
