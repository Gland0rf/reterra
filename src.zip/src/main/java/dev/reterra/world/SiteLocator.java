package dev.reterra.world;

import static net.minecraft.server.command.CommandManager.literal;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import net.minecraft.block.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkStatus;

/** Searches real generated sites, one asynchronous chunk request at a time across the server. */
public final class SiteLocator {
  private SiteLocator() {}
  private static final ArrayDeque<Search> JOBS = new ArrayDeque<>();
  private static final Map<UUID, Long> COOLDOWN = new HashMap<>();
  private static Search active;
  private static final net.minecraft.server.world.ChunkTicketType<net.minecraft.util.math.ChunkPos> TICKET =
      net.minecraft.server.world.ChunkTicketType.create("reterra_locator",
          Comparator.comparingLong(net.minecraft.util.math.ChunkPos::toLong), 240);
  private static final int RADIUS = 2048;

  private static final class Search {
    final ServerCommandSource source;
    final ResearchSites.Kind kind;
    final ArrayDeque<BlockPos> candidates;
    CompletableFuture<?> pending;
    BlockPos checking;
    int requestedTick;
    Search(ServerCommandSource source, ResearchSites.Kind kind, List<BlockPos> candidates) {
      this.source = source;
      this.kind = kind;
      this.candidates = new ArrayDeque<>(candidates);
    }
  }

  public static List<BlockPos> candidates(long seed, BlockPos from, ResearchSites.Kind kind) {
    List<BlockPos> result = new ArrayList<>();
    int ox = Math.floorDiv(from.getX(), 128), oz = Math.floorDiv(from.getZ(), 128);
    for (int x = ox - 17; x <= ox + 17; x++)
      for (int z = oz - 17; z <= oz + 17; z++) {
        var actual = ResearchSites.kind(seed, x, z);
        if (actual != kind && !(kind == ResearchSites.Kind.FARMHOUSE
            && actual == ResearchSites.Kind.WATERWORKS)) continue;
        BlockPos p = ResearchSites.candidate(seed, x, z);
        if (Math.abs((long) p.getX() - from.getX()) <= RADIUS
            && Math.abs((long) p.getZ() - from.getZ()) <= RADIUS) result.add(p);
      }
    result.sort(Comparator.comparingDouble(p -> horizontalDistance(p, from)));
    return result;
  }

  private static double horizontalDistance(BlockPos a, BlockPos b) {
    return Math.hypot((double) a.getX() - b.getX(), (double) a.getZ() - b.getZ());
  }

  public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
    dispatcher.register(literal("locate").requires(s -> s.hasPermissionLevel(2))
        .then(branch("reterra")));
    // Survival-friendly equivalent; vanilla /locate retains its usual operator permission.
    dispatcher.register(literal("reterra").then(branch("locate")));
    var structures = literal("structure");
    for (var kind : ResearchSites.Kind.values())
      structures.then(literal("reterra:" + kind.name().toLowerCase(Locale.ROOT))
          .executes(c -> start(c.getSource(), kind)));
    dispatcher.register(literal("locate").requires(s -> s.hasPermissionLevel(2)).then(structures));
  }

  private static LiteralArgumentBuilder<ServerCommandSource> branch(String name) {
    var branch = literal(name).executes(c -> {
      c.getSource().sendFeedback(() -> Text.literal(
          "Choose: farmhouse, greenhouse, seed_vault, waterworks, biological_archive, research_station"), false);
      return 1;
    });
    for (var kind : ResearchSites.Kind.values())
      branch.then(literal(kind.name().toLowerCase(Locale.ROOT)).executes(c -> start(c.getSource(), kind)));
    return branch;
  }

  private static int start(ServerCommandSource source, ResearchSites.Kind kind) {
    if (!source.getWorld().getRegistryKey().equals(World.OVERWORLD)) {
      source.sendError(Text.literal("ReTerra ruins are found in the Overworld."));
      return 0;
    }
    var player = source.getPlayer();
    if (player != null) {
      long now = source.getServer().getTicks();
      if (COOLDOWN.getOrDefault(player.getUuid(), Long.MIN_VALUE / 2) + 200 > now) {
        source.sendError(Text.literal("Please wait a moment before starting another search."));
        return 0;
      }
      if ((active != null && active.source.getPlayer() == player)
          || JOBS.stream().anyMatch(j -> j.source.getPlayer() == player)) {
        source.sendError(Text.literal("Your structure search is still running."));
        return 0;
      }
      COOLDOWN.put(player.getUuid(), now);
    }
    if (JOBS.size() >= 8) {
      source.sendError(Text.literal("Other explorers are searching. Try again shortly."));
      return 0;
    }
    BlockPos from = BlockPos.ofFloored(source.getPosition());
    List<BlockPos> positions = candidates(source.getWorld().getSeed(), from, kind);
    dev.reterra.state.RestorationState.get(source.getWorld()).knownSites.forEach((packed, name) -> {
      BlockPos pos = BlockPos.fromLong(packed);
      if (name.equals(kind.name()) && Math.abs((long) pos.getX() - from.getX()) <= RADIUS
          && Math.abs((long) pos.getZ() - from.getZ()) <= RADIUS
          && positions.stream().noneMatch(p -> p.getX() == pos.getX() && p.getZ() == pos.getZ())) positions.add(pos);
    });
    positions.sort(Comparator.comparingDouble(p -> horizontalDistance(p, from)));
    JOBS.add(new Search(source, kind, positions));
    source.sendFeedback(() -> Text.literal("Searching for " + label(kind) + " within 2,048 blocks..."), false);
    return 1;
  }

  public static String label(ResearchSites.Kind kind) {
    String[] words = kind.name().toLowerCase(Locale.ROOT).split("_");
    return String.join(" ", Arrays.stream(words).map(w -> Character.toUpperCase(w.charAt(0)) + w.substring(1)).toList());
  }

  private static void release(Search job) {
    if (job.checking != null) {
      var chunk = new net.minecraft.util.math.ChunkPos(job.checking);
      job.source.getWorld().getChunkManager().removeTicket(TICKET, chunk, 0, chunk);
    }
  }

  public static void clear() {
    if (active != null) release(active);
    JOBS.clear(); active = null; COOLDOWN.clear();
  }

  public static void tick(MinecraftServer server) {
    if (server.getTicks() % 5 != 0) return;
    if (active == null) active = JOBS.poll();
    if (active == null) return;
    Search job = active;
    var player = job.source.getPlayer();
    if (player != null && (player.isDisconnected() || player.getServerWorld() != job.source.getWorld())) {
      release(job);
      active = null;
      return;
    }
    ServerWorld world = job.source.getWorld();
    if (job.pending != null) {
      if (!job.pending.isDone()) {
        if (server.getTicks() - job.requestedTick < 200) return;
        release(job);
        job.source.sendError(Text.literal("Structure search timed out loading terrain. Try again after the server catches up."));
        active = null;
        return;
      }
      if (!job.pending.isCompletedExceptionally()) {
        var chunk = world.getChunkManager().getChunk(job.checking.getX() >> 4,
            job.checking.getZ() >> 4, ChunkStatus.FULL, false);
        if (chunk != null) {
          BlockPos found = findChest(world, job.checking, job.kind);
          if (found != null) {
            int distance = (int) horizontalDistance(found, BlockPos.ofFloored(job.source.getPosition()));
            Text coordinates = Text.literal("[" + found.getX() + ", " + found.getY() + ", " + found.getZ() + "]")
                .formatted(Formatting.GREEN).styled(s -> s
                    .withClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND,
                        "/tp @s " + found.getX() + " " + (found.getY() + 1) + " " + found.getZ()))
                    .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal("Suggest teleport command"))));
            job.source.sendFeedback(() -> Text.literal(label(job.kind) + " found at ")
                .append(coordinates).append(" (" + distance + " blocks away)."), false);
            release(job);
            active = null;
            return;
          }
        }
      }
      release(job);
      job.pending = null;
    }
    job.checking = job.candidates.poll();
    if (job.checking == null) {
      job.source.sendError(Text.literal("No intact " + label(job.kind) + " found within 2,048 blocks. Explore farther and try again."));
      active = null;
      return;
    }
    if (!world.getWorldBorder().contains(job.checking)) return;
    var chunk = new net.minecraft.util.math.ChunkPos(job.checking);
    world.getChunkManager().addTicket(TICKET, chunk, 0, chunk);
    job.requestedTick = server.getTicks();
    job.pending = world.getChunkManager().getChunkFutureSyncOnMainThread(job.checking.getX() >> 4,
        job.checking.getZ() >> 4, ChunkStatus.FULL, true);
  }

  public static BlockPos findChest(ServerWorld world, BlockPos candidate, ResearchSites.Kind kind) {
    BlockPos offset = ResearchSites.chestPosition(candidate, kind);
    int top = world.getTopY(Heightmap.Type.WORLD_SURFACE, offset.getX(), offset.getZ());
    for (int y = top; y >= Math.max(world.getBottomY(), top - 32); y--) {
      BlockPos chest = new BlockPos(offset.getX(), y, offset.getZ());
      if (world.getBlockState(chest).isOf(Blocks.CHEST)) {
        // Archives and Waterworks share a chest offset. Verify their very different foundations.
        if (kind == ResearchSites.Kind.BIOLOGICAL_ARCHIVE
            && !world.getBlockState(chest.down()).isOf(Blocks.CALCITE)) continue;
        if (kind == ResearchSites.Kind.WATERWORKS
            && !world.getBlockState(new BlockPos(candidate.getX() + 3, y - 1, candidate.getZ())).isOf(Blocks.COPPER_BLOCK)) continue;
        return chest;
      }
    }
    return null;
  }
}
