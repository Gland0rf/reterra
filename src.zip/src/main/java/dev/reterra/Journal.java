package dev.reterra;

import net.minecraft.server.network.ServerPlayerEntity;

/** Milestone helper. Progress is explained by discoveries, item tooltips and machine screens. */
public final class Journal {
  private Journal() {}

  public static void grant(ServerPlayerEntity player, String path) {
    var advancement = player.getServer().getAdvancementLoader().get(Content.id(path));
    if (advancement != null)
      for (String criterion : advancement.value().criteria().keySet())
        player.getAdvancementTracker().grantCriterion(advancement, criterion);
    discover(player, path);
  }

  public static void discover(ServerPlayerEntity player, String entry) {
    var state = dev.reterra.state.RestorationState.get(player.getServer().getOverworld());
    if (state
        .discoveries
        .computeIfAbsent(player.getUuid(), id -> new java.util.HashSet<>())
        .add(entry)) state.markDirty();
  }

  public static dev.reterra.screen.GuidePayload payload(ServerPlayerEntity player) {
    return progress(player, true);
  }

  private static dev.reterra.screen.GuidePayload progress(ServerPlayerEntity player, boolean open) {
    var state = dev.reterra.state.RestorationState.get(player.getServer().getOverworld());
    var notes = state.discoveries.getOrDefault(player.getUuid(), java.util.Set.of());
    var core =
        dev.reterra.machine.RestorationEngine.regionAt(
            dev.reterra.state.RestorationState.get(player.getServerWorld()), player.getBlockPos());
    boolean seeds = notes.contains("seeds") || notes.contains("the_last_seed");
    boolean compost = notes.contains("compost"),
        dirt = notes.contains("dirt"),
        wheat = notes.contains("wheat");
    boolean registered = notes.contains("greener_world") || core != null;
    boolean habitat = core != null && core.survey(0).habitat(core.family);
    int chapter = !seeds ? 0 : !wheat || !dirt ? 1 : !registered ? 2 : !habitat ? 3 : 4;
    if (!state.completed.isEmpty() || notes.contains("natures_return")) chapter = 5;
    String objective =
        switch (chapter) {
          case 0 ->
              notes.contains("pouch")
                  ? "Open the Sealed Seed Pouch."
                  : state.firstSite == null
                      ? "Look for a farmhouse chimney."
                      : "Farmhouse: "
                          + direction(player.getBlockPos(), state.firstSite)
                          + ", "
                          + (int)
                              Math.sqrt(player.getBlockPos().getSquaredDistance(state.firstSite))
                          + " blocks.";
          case 1 -> "Establish your first wheat farm.";
          case 2 -> "Build and register a Restoration Core.";
          case 3 -> "Grow a habitat for the first wildlife.";
          case 4 -> "Incubate and protect two animal species.";
          default ->
              state.heartActivated
                  ? "The Heart is alive. Keep rebuilding."
                  : "Reclaim distinct ecosystems: " + state.completed.size() + " / 4.";
        };
    String checklist =
        switch (chapter) {
          case 0, 1 ->
              check(seeds, "Recover preserved seeds")
                  + "\n"
                  + check(compost, "Make organic compost")
                  + "\n"
                  + check(dirt, "Restore fertile dirt")
                  + "\n"
                  + check(wheat, "Harvest your first wheat");
          case 2 ->
              check(notes.contains("culture"), "Grow a grass culture")
                  + "\n"
                  + check(notes.contains("reclaimer"), "Craft a Soil Reclaimer")
                  + "\n"
                  + check(registered, "Register a Core region");
          case 3, 4 ->
              check(habitat, "Establish soil, water and varied plants")
                  + "\n"
                  + check(notes.contains("sample"), "Recover preserved animal tissue")
                  + "\n"
                  + check(notes.contains("natures_return"), "Incubate your first pair");
          default ->
              java.util.Arrays.stream(dev.reterra.ecology.Ecology.Family.values())
                  .map(
                      f ->
                          check(
                              state.completed.contains(f),
                              f.name().charAt(0)
                                  + f.name().substring(1).toLowerCase(java.util.Locale.ROOT)))
                  .collect(java.util.stream.Collectors.joining("\n"));
        };
    int completed =
        state.completed.stream().mapToInt(f -> 1 << f.ordinal()).reduce(0, (a, b) -> a | b);
    return new dev.reterra.screen.GuidePayload(chapter, completed, objective, checklist, open);
  }

  private static String check(boolean done, String task) {
    return (done ? "[x] " : "[ ] ") + task;
  }

  public static String direction(
      net.minecraft.util.math.BlockPos from, net.minecraft.util.math.BlockPos to) {
    int dx = to.getX() - from.getX(), dz = to.getZ() - from.getZ();
    if (Math.abs(dx) < 12 && Math.abs(dz) < 12) return "nearby";
    String ns = Math.abs(dz) > 12 ? dz < 0 ? "north" : "south" : "";
    String ew = Math.abs(dx) > 12 ? dx < 0 ? "west" : "east" : "";
    return ns.isEmpty() ? ew : ew.isEmpty() ? ns : ns + "-" + ew;
  }

  public static void tick(net.minecraft.server.world.ServerWorld world) {
    for (var player : world.getPlayers()) {
      for (var stack : player.getInventory().main) {
        if (stack.isOf(net.minecraft.item.Items.WHEAT_SEEDS)) discover(player, "seeds");
        if (stack.isOf(Content.RECOVERY_BUNDLE)) discover(player, "pouch");
        if (stack.isOf(Content.COMPOST)) discover(player, "compost");
        if (stack.isOf(net.minecraft.item.Items.DIRT)) discover(player, "dirt");
        if (stack.isOf(net.minecraft.item.Items.WHEAT)) discover(player, "wheat");
        if (stack.isOf(Content.CULTURE)) discover(player, "culture");
        if (stack.isOf(Content.RECLAIMER.asItem())) discover(player, "reclaimer");
        if (dev.reterra.machine.MachineLogic.sample(stack)) discover(player, "sample");
      }
      var state = dev.reterra.state.RestorationState.get(world);
      if (state.firstSite != null
          && !state
              .discoveries
              .getOrDefault(player.getUuid(), java.util.Set.of())
              .contains("site_hint")) {
        player.sendMessage(
            net.minecraft.text.Text.literal(
                "A farmhouse stands "
                    + direction(player.getBlockPos(), state.firstSite)
                    + " of here. Look for its chimney."),
            false);
        discover(player, "site_hint");
      }
      if (state.firstSite != null
          && dev.reterra.machine.RestorationEngine.loaded(world, state.firstSite)
          && player.squaredDistanceTo(net.minecraft.util.math.Vec3d.ofCenter(state.firstSite))
              < 192 * 192
          && !state
              .discoveries
              .getOrDefault(player.getUuid(), java.util.Set.of())
              .contains("seeds"))
        world.spawnParticles(
            net.minecraft.particle.ParticleTypes.CAMPFIRE_COSY_SMOKE,
            state.firstSite.getX() - 3.5,
            state.firstSite.getY() + 7,
            state.firstSite.getZ() - 1.5,
            2,
            .1,
            .1,
            .1,
            .03);
      if (net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.canSend(
          player, dev.reterra.screen.GuidePayload.ID))
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(
            player, progress(player, false));
    }
  }
}
