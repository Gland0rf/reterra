package dev.reterra.client;

import dev.reterra.Content;
import dev.reterra.machine.MachineLogic;
import dev.reterra.machine.Multiblocks;
import dev.reterra.screen.MachineScreenHandler;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class MachineScreen extends HandledScreen<MachineScreenHandler> {
  private ButtonWidget primary, secondary;
  private static final int INK = 0xFFDEDCC9, MUTED = 0xFFA2AA9A, GREEN = 0xFF8DB66D;

  public MachineScreen(MachineScreenHandler handler, PlayerInventory inventory, Text title) {
    super(handler, inventory, title);
    backgroundWidth = 300;
    backgroundHeight = 260;
    titleX = 12;
    titleY = 9;
    playerInventoryTitleX = 69;
    playerInventoryTitleY = 161;
  }

  @Override
  protected void init() {
    super.init();
    String[] tabs = {"Use", "Build", "Habitat", "Help"};
    for (int i = 0; i < 4; i++) {
      int id = i + 10;
      addDrawableChild(
          ButtonWidget.builder(Text.literal(tabs[i]), b -> click(id))
              .dimensions(x + 12 + i * 70, y + 25, 66, 14)
              .build());
    }
    primary =
        addDrawableChild(
            ButtonWidget.builder(Text.empty(), b -> primary())
                .dimensions(x + 12, y + 137, 134, 16)
                .build());
    secondary =
        addDrawableChild(
            ButtonWidget.builder(Text.empty(), b -> secondary())
                .dimensions(x + 154, y + 137, 134, 16)
                .build());
    updateButtons();
  }

  private void click(int id) {
    if (client != null && client.interactionManager != null)
      client.interactionManager.clickButton(handler.syncId, id);
  }

  private void primary() {
    if (handler.value(26) != 0) click(10);
    else if (handler.kind() == 0 || handler.kind() == 2) click(0);
    else if (handler.kind() == 1 && handler.value(7) != 0) click(2);
    else click(1);
  }

  private void secondary() {
    if (handler.value(26) == 0 && handler.kind() == 3 && handler.value(33) > 0) click(3);
    else if (handler.value(26) == 3 && client != null)
      FieldGuideScreen.open(
          client,
          switch (handler.kind()) {
            case 0, 2 -> 2;
            case 1 -> 3;
            case 3 -> 4;
            default -> 5;
          });
    else if (handler.value(26) == 1) click(12);
    else if (handler.value(26) == 2) click(handler.kind() == 1 ? 4 : 11);
    else if (handler.kind() < 3 && handler.kind() != 1) click(2);
    else click(12);
  }

  private void updateButtons() {
    if (primary == null) return;
    boolean operate = handler.value(26) == 0;
    String label =
        !operate
            ? "Back to controls"
            : switch (handler.kind()) {
              case 0 -> handler.value(5) == 1 ? "Mode: make soil" : "Mode: restore terrain";
              case 1 ->
                  handler.value(7) == 0
                      ? "Register region"
                      : handler.value(6) == 1 ? "Resume restoration" : "Pause restoration";
              case 2 -> handler.value(39) == 1 ? "Mode: recover river" : "Mode: irrigate";
              case 3 -> handler.value(33) > 0 ? "Incubating..." : "Revive pair";
              default -> handler.value(21) != 0 ? "Heart awakened" : "Awaken Heart";
            };
    primary.setMessage(Text.literal(label));
    primary.active = !operate || (!handler.readOnly() && handler.value(20) == 0);
    if (operate && handler.kind() == 4 && (handler.value(21) != 0 || handler.value(25) < 4))
      primary.active = false;
    if (operate
        && handler.kind() == 3
        && (handler.value(33) > 0 || handler.value(8) != MachineLogic.Status.READY.ordinal()))
      primary.active = false;
    secondary.setMessage(
        Text.literal(
            handler.value(26) == 0 && handler.kind() == 3 && handler.value(33) > 0
                ? "Cancel incubation"
                : handler.value(26) == 1
                    ? "Habitat"
                    : handler.value(26) == 2
                        ? handler.kind() == 1
                            ? handler.value(42) != 0 ? "Hide boundary" : "Show boundary"
                            : "Build"
                        : handler.value(26) == 3
                            ? "Field guide (J)"
                            : handler.kind() < 3 && handler.kind() != 1
                                ? (handler.value(6) == 1 ? "Resume" : "Pause")
                                : "Habitat"));
    secondary.active =
        handler.value(26) != 0
            || handler.kind() >= 3
            || handler.kind() == 1
            || (!handler.readOnly() && handler.value(20) == 0);
  }

  @Override
  protected void handledScreenTick() {
    super.handledScreenTick();
    updateButtons();
  }

  @Override
  public void render(DrawContext context, int mouseX, int mouseY, float delta) {
    super.render(context, mouseX, mouseY, delta);
    drawMouseoverTooltip(context, mouseX, mouseY);
    if (mouseX >= x + 10 && mouseX < x + 290 && mouseY >= y + 42 && mouseY < y + 54)
      context.drawTooltip(textRenderer, statusDetails(), mouseX, mouseY);
    if (handler.value(26) == 0
        && handler.kind() < 4
        && mouseX >= x + 10
        && mouseX < x + 200
        && mouseY >= y + 117
        && mouseY < y + 130)
      context.drawTooltip(textRenderer, Text.literal("128 water units per bucket"), mouseX, mouseY);
    if (handler.value(26) == 0)
      for (int i = 0; i < 8; i++)
        if (MachineLogic.visible(handler.kind(), i)
            && mouseX >= x + MachineScreenHandler.SLOT_X[i] - 1
            && mouseX < x + MachineScreenHandler.SLOT_X[i] + 17
            && mouseY >= y + 95
            && mouseY < y + 114
            && handler.slots.get(i).getStack().isEmpty())
          context.drawTooltip(textRenderer, wrap(slotHint(i).getString()), mouseX, mouseY);
    if (handler.value(26) == 2)
      for (int i = 0; i < 9; i++) {
        int px = x + 12 + i % 2 * 144, py = y + 77 + i / 2 * 11;
        if (mouseX >= px && mouseX < px + 140 && mouseY >= py && mouseY < py + 10)
          context.drawTooltip(textRenderer, wrap(goalHint(i)), mouseX, mouseY);
      }
    if (handler.value(26) == 1)
      for (var p : Multiblocks.parts(handler.kindName(), handler.value(32))) {
        int px = p.y() < 0 ? 82 : 48 + p.x() * 16, py = p.y() < 0 ? 118 : 84 + p.z() * 16;
        if (mouseX >= x + px && mouseX < x + px + 12 && mouseY >= y + py && mouseY < y + py + 12)
          context.drawTooltip(textRenderer, Text.literal(p.description()), mouseX, mouseY);
      }
  }

  @Override
  protected void drawBackground(DrawContext c, float delta, int mouseX, int mouseY) {
    c.fill(x, y, x + 300, y + 260, 0xFF765840);
    c.fill(x + 2, y + 2, x + 298, y + 258, 0xFF252F2B);
    c.fill(x + 5, y + 42, x + 295, y + 133, 0xFF1A231F);
    c.fill(x + 5, y + 158, x + 295, y + 159, 0xFF657554);
    for (int i = 8; i < handler.slots.size(); i++) {
      var s = handler.slots.get(i);
      slot(c, x + s.x, y + s.y);
    }
    if (handler.value(26) == 0) {
      for (int i = 0; i < 8; i++)
        if (MachineLogic.visible(handler.kind(), i)) {
          int sx = x + MachineScreenHandler.SLOT_X[i], sy = y + 96;
          slot(c, sx, sy);
          if (handler.slots.get(i).getStack().isEmpty()) {
            c.drawItem(ghost(i), sx, sy);
            c.fill(sx, sy, sx + 16, sy + 16, 0x88252F2B);
          }
        }
    }
  }

  private void slot(DrawContext c, int px, int py) {
    c.fill(px - 1, py - 1, px + 17, py + 17, 0xFF0F1713);
    c.fill(px, py, px + 17, py + 17, 0xFF55614E);
    c.fill(px, py, px + 16, py + 16, 0xFF303D32);
  }

  @Override
  protected void drawForeground(DrawContext c, int mouseX, int mouseY) {
    c.drawText(textRenderer, title, 12, 9, INK, false);
    c.drawText(textRenderer, playerInventoryTitle, 69, 161, MUTED, false);
    String status = statusText();
    c.drawText(
        textRenderer,
        textRenderer.trimToWidth(status, handler.value(26) == 1 ? 176 : 276),
        handler.value(26) == 1 ? 112 : 12,
        45,
        statusColor(),
        false);
    switch (handler.value(26)) {
      case 0 -> {
        c.drawTextWrapped(textRenderer, Text.literal(nextStep()), 12, 58, 276, INK);
        if (handler.kind() < 4) {
          for (int i = 0; i < 6; i++)
            if (MachineLogic.visible(handler.kind(), i))
              c.drawText(
                  textRenderer,
                  supplyLabel(i),
                  MachineScreenHandler.SLOT_X[i] - 1,
                  85,
                  MUTED,
                  false);
          if (handler.kind() == 0 || handler.kind() == 2)
            c.drawText(textRenderer, "Output", 240, 85, MUTED, false);
        }
        if (handler.kind() < 4) {
          c.drawText(
              textRenderer,
              "Water " + handler.value(3) + " / " + dev.reterra.machine.Balance.TANK_CAPACITY,
              12,
              119,
              0xFF8CB7D6,
              false);
          c.fill(123, 119, 199, 127, 0xFF10232C);
          c.fill(
              123,
              119,
              123 + Math.min(76, handler.value(3) * 76 / dev.reterra.machine.Balance.TANK_CAPACITY),
              127,
              0xFF508EAC);
          if (handler.kind() == 3 && handler.value(33) > 0) {
            int seconds = (handler.value(33) - 1) / 20;
            c.drawText(textRenderer, seconds + " / 20s", 216, 119, GREEN, false);
            c.fill(210, 131, 210 + Math.min(76, (handler.value(33) - 1) * 76 / 400), 134, GREEN);
          }
        }
      }
      case 1 -> blueprint(c);
      case 2 -> habitat(c);
      case 3 -> help(c);
    }
  }

  private int statusColor() {
    return handler.value(8) == MachineLogic.Status.READY.ordinal()
            || handler.value(8) == MachineLogic.Status.COMPLETE.ordinal()
            || handler.value(8) == MachineLogic.Status.STABILIZING.ordinal()
            || handler.value(20) != 0
        ? GREEN
        : 0xFFE0B57C;
  }

  private String statusText() {
    if (handler.value(26) == 1) return "Assembly - rotates freely";
    if (handler.value(26) == 2)
      return family().name().charAt(0)
          + family().name().substring(1).toLowerCase(java.util.Locale.ROOT)
          + " habitat";
    if (handler.value(26) == 3) return "How this machine helps";
    if (handler.value(24) == MachineLogic.Status.NO_SPACE.ordinal())
      return "Clear two air blocks above nearby grass";
    if (handler.value(24) == MachineLogic.Status.REVIVED.ordinal())
      return "Wildlife revived - protect a breeding population";
    return Text.translatable(
            "status.reterra."
                + MachineLogic.Status.values()[
                    Math.min(handler.value(8), MachineLogic.Status.values().length - 1)]
                    .name()
                    .toLowerCase(java.util.Locale.ROOT))
        .getString();
  }

  private List<Text> statusDetails() {
    List<Text> lines = new ArrayList<>();
    lines.add(Text.literal(statusText()).formatted(Formatting.GOLD));
    int issue = handler.value(9);
    var parts = Multiblocks.parts(handler.kindName(), handler.value(32));
    if (issue > 0 && issue <= parts.size())
      lines.add(Text.literal(parts.get(issue - 1).description()));
    if (handler.kind() == 1) {
      lines.add(
          Text.literal(
              "Soil "
                  + handler.value(10)
                  + "% / "
                  + targets()[0]
                  + "%; grass "
                  + handler.value(11)
                  + "% / "
                  + targets()[1]
                  + "%"));
      lines.add(Text.literal("Surveyed: " + handler.value(18) + " columns. 3 x 3 chunks."));
      lines.add(
          Text.literal(
              "Animal types: "
                  + handler.value(29)
                  + " / 2; stable "
                  + handler.value(28)
                  + " / 180 sec"));
    }
    lines.add(
        Text.literal(
            "Stored work: soil "
                + handler.value(1)
                + ", energy "
                + handler.value(2)
                + ", water "
                + handler.value(3)));
    if (handler.kind() == 1) lines.add(Text.literal("Grass seeding reserve: " + handler.value(4)));
    if (handler.value(41) != 0)
      lines.add(Text.literal("Ecosystem research: +25% compost, culture and fuel yield."));
    lines.add(Text.literal("No fuel is charged for scanning or waiting."));
    return lines;
  }

  private void blueprint(DrawContext c) {
    blueprintIcon(
        c,
        new ItemStack(net.minecraft.registry.Registries.ITEM.get(Content.id(handler.kindName()))),
        48,
        84);
    var parts = Multiblocks.parts(handler.kindName(), handler.value(32));
    int issue = handler.value(9);
    for (int i = 0; i < parts.size(); i++) {
      var p = parts.get(i);
      int px = p.y() < 0 ? 82 : 48 + p.x() * 16, py = p.y() < 0 ? 118 : 84 + p.z() * 16;
      c.fill(px - 1, py - 1, px + 13, py + 13, issue == i + 1 ? 0xFFA5754D : 0xFF465B43);
      blueprintIcon(c, new ItemStack(p.block()), px, py);
    }
    c.drawText(textRenderer, "Below", 78, 106, MUTED, false);
    String detail =
        issue == 0
            ? "Assembly complete. Open Use to add supplies."
            : parts.get(Math.min(parts.size() - 1, issue - 1)).description();
    c.drawTextWrapped(textRenderer, Text.literal(detail), 112, 57, 174, INK);
    c.drawTextWrapped(
        textRenderer,
        Text.literal("Any rotation works. Cauldrons need water."),
        112,
        89,
        174,
        MUTED);
  }

  private void habitat(DrawContext c) {
    c.drawTextWrapped(textRenderer, Text.literal(nextGoal()), 12, 57, 276, INK);
    String[] labels = {
      "Soil",
      "Grass",
      "Water",
      "Crops",
      "Leaf cover",
      "Flowers",
      "Plant types",
      "Animal types",
      bonusLabel()
    };
    int[] values = measurements();
    int[] targets = targets();
    for (int i = 0; i < 9; i++) {
      int px = 12 + (i % 2) * 144, py = 77 + (i / 2) * 11;
      if (i == 8 && targets[i] == 0) continue;
      if (i == 7 && handler.kind() == 3) {
        c.drawText(textRenderer, "No adults needed!", px, py, GREEN, false);
        continue;
      }
      int color = values[i] >= targets[i] ? GREEN : MUTED;
      c.drawText(
          textRenderer,
          targets[i] == 0
              ? labels[i] + ": optional"
              : labels[i] + " " + values[i] + " / " + targets[i] + (i < 2 ? "%" : ""),
          px,
          py,
          color,
          false);
      c.fill(px, py + 9, px + 132, py + 10, 0xFF354638);
      c.fill(
          px,
          py + 9,
          px + Math.min(132, values[i] * 132 / Math.max(1, targets[i])),
          py + 10,
          color);
    }
  }

  private int[] targets() {
    var g = dev.reterra.ecology.Ecology.goals(family());
    return handler.kind() == 3
        ? new int[] {35, 15, 4, Math.min(4, g.crops()), 1, 1, 3, 0, 0}
        : new int[] {
          g.soil(),
          g.grass(),
          g.water(),
          g.crops(),
          g.trees(),
          g.flowers(),
          g.species(),
          2,
          Math.max(g.treeTypes(), Math.max(g.wetland(), g.slopes()))
        };
  }

  private dev.reterra.ecology.Ecology.Family family() {
    return dev.reterra.ecology.Ecology.Family.values()[Math.clamp(handler.value(23), 0, 3)];
  }

  private int[] measurements() {
    return new int[] {
      handler.value(10),
      handler.value(11),
      handler.value(12),
      handler.value(13),
      handler.value(14),
      handler.value(15),
      handler.value(16),
      handler.value(29),
      switch (family()) {
        case FOREST -> handler.value(36);
        case SWAMP -> handler.value(37);
        case HIGHLANDS -> handler.value(38);
        default -> 0;
      }
    };
  }

  private String bonusLabel() {
    return switch (family()) {
      case FOREST -> "Tree types";
      case SWAMP -> "Waterside";
      case HIGHLANDS -> "Fertile slopes";
      default -> "";
    };
  }

  private String nextGoal() {
    if (handler.value(20) != 0)
      return "Reclaimed - recovery area "
          + ((handler.value(34) * 2 + 1) * 16)
          + " x "
          + ((handler.value(34) * 2 + 1) * 16)
          + " blocks.";
    if (handler.value(18) < 128 || (handler.kind() != 3 && handler.value(30) < 9))
      return "Surveying " + handler.value(30) + "/9 chunks (about 18 seconds).";
    int[] values = measurements();
    int[] goals = targets();
    for (int i = 0; i < goals.length; i++) if (values[i] < goals[i]) return goalHint(i);
    if (handler.kind() == 3)
      return "Habitat ready! Add a sample, matching food, nutrient culture and water.";
    if (handler.value(20) != 0)
      return "Reclaimed! Scarred soil and dead trunks now recover naturally.";
    if (handler.value(31) == 0)
      return "Trial paused at " + handler.value(28) + "/180 sec; some chunks are unloaded.";
    return "Healthy habitat: "
        + handler.value(28)
        + "/180 sec. Keep crops, plants and animals in the region.";
  }

  private String goalHint(int i) {
    return switch (i) {
      case 0 -> "Restore more soil.";
      case 1 -> "Seed grass on restored dirt.";
      case 2 -> "Add surface water.";
      case 3 -> "Plant more crops within the 48 x 48 region.";
      case 4 -> "Grow trees for leaf cover.";
      case 5 -> "Compost or bone meal on grass grows flowers.";
      case 6 -> "Grow different crops, flowers or tree types.";
      case 8 ->
          switch (family()) {
            case FOREST -> "Grow two tree species: leaf types count.";
            case SWAMP -> "Plant cane, saplings, mushrooms or lilies beside surface water.";
            case HIGHLANDS -> "Restore dirt, grass or moss on slopes; terraces also count.";
            default -> "";
          };
      default ->
          handler.kind() == 3
              ? "No animals required to revive your first pair."
              : "Establish two adult animal types.";
    };
  }

  private String supplyLabel(int i) {
    return switch (i) {
      case 0 -> handler.kind() == 2 ? "Filter" : "Soil";
      case 1 -> "Fuel";
      case 2 -> "Water";
      case 3 ->
          switch (handler.kind()) {
            case 0 -> "Gravel";
            case 1 -> "Grass";
            case 2 -> "Bucket";
            default -> "Sample";
          };
      case 4 -> "Food";
      default -> "Culture";
    };
  }

  private String nextStep() {
    var status =
        MachineLogic.Status.values()[
            Math.clamp(handler.value(8), 0, MachineLogic.Status.values().length - 1)];
    return switch (status) {
      case ASSEMBLY -> "Open Build: it shows the next missing block and exactly where to place it.";
      case REGISTER ->
          "Core: register this region. Chamber: build inside a registered Core region.";
      case HABITAT -> nextGoal();
      case SAMPLE -> "Animal sample required.";
      case FOOD -> "4 wheat/seeds, or 2 flowers for bees.";
      case NUTRIENTS -> "Nutrient culture required.";
      case COMPOST -> handler.kind() == 2 ? "Charcoal filter required." : "Compost required.";
      case FUEL -> "Coal, charcoal or nutrient culture required.";
      case WATER -> "Water bucket required.";
      case CULTURE -> "Grass culture required.";
      case READY ->
          handler.kind() == 1
              ? nextGoal()
              : handler.kind() == 3
                  ? "Ready to incubate. Clear grass beside the chamber."
                  : handler.kind() == 0
                      ? "Processes gravel and coarse dirt into soil."
                      : handler.value(39) != 0
                          ? "Refills riverbeds within 12 blocks. Restored: " + handler.value(40)
                          : "Supplies machine tanks within 8 blocks.";
      case OBJECTIVES ->
          "Reclaim plains, forest, swamp and highlands: " + handler.value(25) + "/4 ecosystems.";
      case RECLAIMED -> nextGoal();
      case STABILIZING -> nextGoal();
      case INCUBATING -> "Incubating " + Math.max(0, handler.value(33) - 1) / 20 + " / 20 seconds.";
      case POPULATION -> "Adult population is at capacity (16).";
      case COMPLETE -> "Recovery aura: 272 x 272. Completed regions spread twice as fast.";
      default -> "";
    };
  }

  private void help(DrawContext c) {
    String text =
        switch (handler.kind()) {
          case 0 ->
              "Makes soil from gravel or coarse dirt. Terrain mode restores a 15 x 15 area. One"
                  + " compost restores 32 blocks.";
          case 1 ->
              "Restores a 48 x 48 region. Needs a furnace below. After reclamation, nature spreads"
                  + " up to 144 x 144 while loaded.";
          case 2 ->
              "Irrigation supplies machines within 8 blocks. River mode refills natural channels"
                  + " within 12 blocks, up to 2 sources per second. Needs water, filters and fuel.";
          case 3 ->
              "Incubation takes 20 seconds. Needs a sample, nutrient medium, water and food: 4"
                  + " wheat/seeds or 2 flowers. Animals emerge beside the chamber.";
          default ->
              "Four reclaimed ecosystems awaken a permanent 272 x 272 recovery aura. Nature regrows"
                  + " in loaded terrain; completed regions spread twice as fast.";
        };
    c.drawTextWrapped(textRenderer, Text.literal(text), 12, 59, 276, INK);
  }

  private ItemStack ghost(int slot) {
    return new ItemStack(
        switch (slot) {
          case 0 -> handler.kind() == 2 ? Content.FILTER : Content.COMPOST;
          case 1 -> Items.CHARCOAL;
          case 2 -> Items.WATER_BUCKET;
          case 3 ->
              switch (handler.kind()) {
                case 0 -> Items.GRAVEL;
                case 1 -> Content.CULTURE;
                case 2 -> Items.BUCKET;
                default -> Content.SHEEP_SAMPLE;
              };
          case 4 -> Items.WHEAT;
          case 5 -> Content.NUTRIENTS;
          case 6 -> handler.kind() == 2 ? Items.WATER_BUCKET : Items.DIRT;
          default -> Items.BUCKET;
        });
  }

  private Text slotHint(int slot) {
    return Text.literal(
        switch (slot) {
          case 0 ->
              handler.kind() == 2
                  ? "Charcoal filter: 8 pump cycles"
                  : "Compost: " + (handler.value(41) != 0 ? 40 : 32) + " soil blocks";
          case 1 ->
              handler.value(41) != 0 && handler.kind() < 2
                  ? "Coal/charcoal: 160 work; nutrients: 320"
                  : "Coal/charcoal: 128 work; nutrients: 256";
          case 2 -> "Water bucket: 128 water units";
          case 3 ->
              switch (handler.kind()) {
                case 0 -> "Coarse dirt or gravel";
                case 1 -> "Grass culture: " + (handler.value(41) != 0 ? 160 : 128) + " blocks";
                case 2 -> "Empty buckets";
                default -> "Animal sample";
              };
          case 4 -> "4 wheat/seeds, or 2 flowers";
          case 5 -> "Nutrient culture";
          case 6 -> "Output";
          default -> "Buckets from an older machine";
        });
  }

  private void blueprintIcon(DrawContext c, ItemStack item, int px, int py) {
    c.getMatrices().push();
    c.getMatrices().translate(px, py, 0);
    c.getMatrices().scale(0.75f, 0.75f, 1);
    c.drawItem(item, 0, 0);
    c.getMatrices().pop();
  }

  private List<Text> wrap(String text) {
    List<Text> lines = new ArrayList<>();
    StringBuilder line = new StringBuilder();
    for (String word : text.split(" ")) {
      if (line.length() + word.length() > 46) {
        lines.add(Text.literal(line.toString()));
        line.setLength(0);
      }
      if (!line.isEmpty()) line.append(' ');
      line.append(word);
    }
    if (!line.isEmpty()) lines.add(Text.literal(line.toString()));
    return lines;
  }
}
