package dev.reterra.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** A short, always available in-game journey, one task at a time. No item or wiki required. */
public final class FieldGuideScreen extends Screen {
  private static dev.reterra.screen.GuidePayload progress = initial();
  private static int remembered, lastObjective = -1;

  private static dev.reterra.screen.GuidePayload initial() {
    return new dev.reterra.screen.GuidePayload(
        0,
        0,
        "Look for a farmhouse chimney.",
        "[ ] Recover preserved seeds\n"
            + "[ ] Make organic compost\n"
            + "[ ] Restore fertile dirt\n"
            + "[ ] Harvest your first wheat",
        false);
  }

  public static void update(dev.reterra.screen.GuidePayload value) {
    progress = value;
  }

  public static void reset() {
    progress = initial();
    remembered = 0;
    lastObjective = -1;
  }

  private int page;
  private int left, top, panelWidth, panelHeight, scroll, maxScroll;
  private static final String[] TITLES = {
    "1. Recover seeds", "2. Build a farm", "3. Restore soil",
    "4. Grow a habitat", "5. Bring back wildlife", "6. Reclaim the world"
  };
  private static final String[][] PAGES = {
    {
      "Farmhouses have timber roofs, stone chimneys and irrigated garden beds. Right-click their"
          + " Sealed Seed Pouch to recover two wheat seeds and a mushroom.",
      "Keep the living finds. The crafting recipe book reveals their uses. /reterra locate"
          + " farmhouse is available if you get lost."
    },
    {
      "One mushroom or rotten flesh with a log makes four compost. Mix one compost with four gravel"
          + " or coarse dirt for four dirt. Till beside water and plant seeds.",
      "Three harvested wheat makes eight compost. Save seeds and expand the farm."
    },
    {
      "Bottle + wheat seeds + compost makes grass culture. Use it on dirt; collect more from grass"
          + " with an empty bottle.",
      "Craft a Reclaimer, then a Core. Build shows the supports; a furnace belongs underneath."
          + " Supply compost, fuel, water and culture, then register the region."
    },
    {
      "Plant varied vegetation inside the Core's 48 x 48 boundary. Compost or bone meal on grass"
          + " grows flowers. The Habitat tab shows the next missing goal.",
      "Scanner: use for a survey, sneak-use to show the region edge. Forest and swamp habitats need"
          + " no crops. Water Restorers can refill natural riverbeds."
    },
    {
      "Archives preserve one animal sample each. Craft the Chamber with a piston and a circuit;"
          + " circuits use copper, iron, glass and redstone.",
      "Add a sample, nutrient culture, water and four wheat/seeds, or two flowers for bees."
          + " Incubation takes 20 seconds. Leave clear grass beside the chamber."
    },
    {
      "Plains need farms; forests need two tree species; swamps need waterside plants; highlands"
          + " need fertile slopes. Habitat shows each region's targets.",
      "Earn 180 healthy seconds. Unloading pauses; habitat damage slowly reduces progress. The"
          + " first ecosystem improves compost, culture and fuel yields by 25%. Four ecosystems"
          + " unlock the Heart's 272 x 272 recovery aura."
    }
  };

  public FieldGuideScreen() {
    super(Text.literal("ReTerra Field Guide"));
  }

  public FieldGuideScreen(int page) {
    this();
    this.page = Math.clamp(page, 0, TITLES.length - 1);
  }

  public static void open(net.minecraft.client.MinecraftClient client) {
    if (lastObjective != progress.chapter()) remembered = progress.chapter();
    lastObjective = progress.chapter();
    open(client, remembered);
  }

  public static void open(net.minecraft.client.MinecraftClient client, int chapter) {
    if (client.currentScreen instanceof net.minecraft.client.gui.screen.ingame.HandledScreen<?>
        && client.player != null) client.player.closeHandledScreen();
    client.setScreen(new FieldGuideScreen(chapter));
  }

  @Override
  protected void init() {
    panelWidth = Math.min(420, width - 16);
    panelHeight = Math.min(300, height - 16);
    left = (width - panelWidth) / 2;
    top = Math.max(8, (height - panelHeight) / 2);
    int buttonWidth = (panelWidth - 42) / 4, buttonY = top + panelHeight - 32;
    addDrawableChild(
        ButtonWidget.builder(Text.literal("Previous"), b -> turn(-1))
            .dimensions(left + 12, buttonY, buttonWidth, 20)
            .build());
    addDrawableChild(
        ButtonWidget.builder(Text.literal("Next"), b -> turn(1))
            .dimensions(left + 18 + buttonWidth, buttonY, buttonWidth, 20)
            .build());
    addDrawableChild(
        ButtonWidget.builder(
                Text.literal("My goal"),
                b -> {
                  page = remembered = progress.chapter();
                  scroll = 0;
                })
            .dimensions(left + 24 + buttonWidth * 2, buttonY, buttonWidth, 20)
            .build());
    addDrawableChild(
        ButtonWidget.builder(Text.literal("Done"), b -> close())
            .dimensions(left + 30 + buttonWidth * 3, buttonY, buttonWidth, 20)
            .build());
  }

  private void turn(int direction) {
    remembered = page = Math.floorMod(page + direction, TITLES.length);
    scroll = 0;
  }

  @Override
  public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
    scroll = Math.clamp(scroll - (int) (vertical * 18), 0, maxScroll);
    return true;
  }

  @Override
  public void renderBackground(DrawContext c, int mouseX, int mouseY, float delta) {
    super.renderBackground(c, mouseX, mouseY, delta);
    c.fill(left, top, left + panelWidth, top + panelHeight, 0xFF27382D);
    c.drawText(textRenderer, title, left + 12, top + 12, 0xFF9EC586, false);
    c.drawText(textRenderer, Text.literal(TITLES[page]), left + 12, top + 31, 0xFFF1E8CB, false);
    c.enableScissor(left + 10, top + 50, left + panelWidth - 10, top + panelHeight - 43);
    int y = top + 51 - scroll;
    for (var line : textRenderer.wrapLines(Text.literal(progress.objective()), panelWidth - 24)) {
      c.drawText(textRenderer, line, left + 12, y, 0xFF9EC586, false);
      y += 10;
    }
    y += 5;
    if (page == progress.chapter()) {
      for (String task : progress.checklist().split("\n")) {
        c.drawText(
            textRenderer,
            task,
            left + 12,
            y,
            task.startsWith("[x]") ? 0xFF9EC586 : 0xFFDEDCC9,
            false);
        y += 11;
      }
      y += 10;
    } else y += 10;
    for (String paragraph : PAGES[page]) {
      var lines = textRenderer.wrapLines(Text.literal(paragraph), panelWidth - 24);
      for (var line : lines) {
        c.drawText(textRenderer, line, left + 12, y, 0xFFDEDCC9, false);
        y += 10;
      }
      y += 9;
    }
    c.disableScissor();
    maxScroll = Math.max(0, y + scroll - (top + panelHeight - 43));
    if (maxScroll > 0) {
      int track = panelHeight - 115,
          knob = (int) (Math.min(scroll, maxScroll) * (long) track / maxScroll);
      c.fill(
          left + panelWidth - 7,
          top + 53,
          left + panelWidth - 5,
          top + panelHeight - 45,
          0xFF354638);
      c.fill(
          left + panelWidth - 7,
          top + 53 + knob,
          left + panelWidth - 5,
          top + 69 + knob,
          0xFF9EC586);
    }
  }

  @Override
  public boolean shouldPause() {
    return false;
  }
}
