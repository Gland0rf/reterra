package dev.reterra.state;

import dev.reterra.ecology.Ecology;
import dev.reterra.machine.Balance;
import java.util.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventories;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;

public final class RestorationState extends PersistentState {
  private static final Type<RestorationState> TYPE =
      new Type<>(RestorationState::new, RestorationState::read, null);
  public final Map<Long, Machine> machines = new LinkedHashMap<>();
  public final Map<Long, Machine> reclaimedRegions = new LinkedHashMap<>();
  public final Set<Long> protectedBlocks = new HashSet<>();
  public final Set<UUID> startedPlayers = new HashSet<>();
  public final Set<Ecology.Family> completed = EnumSet.noneOf(Ecology.Family.class);
  public final Map<Long, String> knownSites = new LinkedHashMap<>();
  public boolean heartActivated;
  public BlockPos heartPos, firstSite;
  public boolean firstSitePending;
  public int firstSiteCursor, heartTicks, heartCursor;
  public final Map<UUID, Set<String>> discoveries = new HashMap<>();
  public final Set<UUID> boundaryViewers = new HashSet<>();
  public int scheduler;

  public static final class Sector {
    public int cursor, sampled, fertile, grass, water, crops, trees, flowers;
    public final Set<String> species = new HashSet<>();
    public int lastSampled, lastFertile, lastGrass, lastWater, lastCrops, lastTrees, lastFlowers;
    public final Set<String> lastSpecies = new HashSet<>();
    public boolean surveyed;
    public boolean biomeTransitioned;
    public int wetland, slopes, lastWetland, lastSlopes;

    public void finish() {
      surveyed = true;
      lastSampled = sampled;
      lastFertile = fertile;
      lastGrass = grass;
      lastWater = water;
      lastCrops = crops;
      lastTrees = trees;
      lastFlowers = flowers;
      lastWetland = wetland;
      lastSlopes = slopes;
      lastSpecies.clear();
      lastSpecies.addAll(species);
      cursor = sampled = fertile = grass = water = crops = trees = flowers = 0;
      wetland = slopes = 0;
      species.clear();
    }

    NbtCompound write() {
      NbtCompound n = new NbtCompound();
      n.putBoolean("surveyed", surveyed);
      n.putBoolean("biomeTransitioned", biomeTransitioned);
      n.putIntArray("ecology", new int[] {wetland, slopes, lastWetland, lastSlopes});
      n.putIntArray(
          "values",
          new int[] {
            cursor,
            sampled,
            fertile,
            grass,
            water,
            crops,
            trees,
            flowers,
            lastSampled,
            lastFertile,
            lastGrass,
            lastWater,
            lastCrops,
            lastTrees,
            lastFlowers
          });
      n.putString("species", String.join(",", species));
      n.putString("lastSpecies", String.join(",", lastSpecies));
      return n;
    }

    static Sector read(NbtCompound n) {
      Sector s = new Sector();
      int[] a = n.getIntArray("values");
      s.surveyed = n.getBoolean("surveyed");
      s.biomeTransitioned = n.getBoolean("biomeTransitioned");
      int[] ecology = n.getIntArray("ecology");
      if (ecology.length == 4) {
        s.wetland = ecology[0];
        s.slopes = ecology[1];
        s.lastWetland = ecology[2];
        s.lastSlopes = ecology[3];
      }
      if (a.length == 15) {
        s.cursor = a[0];
        s.sampled = a[1];
        s.fertile = a[2];
        s.grass = a[3];
        s.water = a[4];
        s.crops = a[5];
        s.trees = a[6];
        s.flowers = a[7];
        s.lastSampled = a[8];
        s.lastFertile = a[9];
        s.lastGrass = a[10];
        s.lastWater = a[11];
        s.lastCrops = a[12];
        s.lastTrees = a[13];
        s.lastFlowers = a[14];
      }
      if (!n.getString("species").isEmpty())
        s.species.addAll(List.of(n.getString("species").split(",")));
      if (!n.getString("lastSpecies").isEmpty())
        s.lastSpecies.addAll(List.of(n.getString("lastSpecies").split(",")));
      return s;
    }
  }

  public static final class Machine implements Inventory {
    public final BlockPos pos;
    public final String kind;
    public int compost, fuel, water, cursor, sectorCursor;
    public int culture;
    public int stableSeconds, rewildCursor;
    public int revivalTicks, spreadRadius = 1, spreadTicks, biomeCursor;
    public int celebratedStage, riverCursor, riverRestored;
    public boolean riverMode;
    public String pendingSpecies = "";
    public final Set<Long> biomeChunks = new HashSet<>();
    public long lastStableTick;
    public boolean registered, paused;
    public int feedback;
    public final DefaultedList<ItemStack> items = DefaultedList.ofSize(8, ItemStack.EMPTY);
    public Runnable dirty = () -> {};
    public boolean production = true, reclaimed;
    public long lastWildlifeCheck;
    public final Set<String> restoredSpecies = new HashSet<>();
    public String biome = "minecraft:plains";
    public Ecology.Family family = Ecology.Family.PLAINS;
    public final Sector[] sectors = new Sector[9];

    public Machine(BlockPos pos, String kind) {
      this.pos = pos.toImmutable();
      this.kind = kind;
      Arrays.setAll(sectors, i -> new Sector());
    }

    @Override
    public int size() {
      return items.size();
    }

    @Override
    public boolean isEmpty() {
      return items.stream().allMatch(ItemStack::isEmpty);
    }

    @Override
    public ItemStack getStack(int slot) {
      return items.get(slot);
    }

    @Override
    public ItemStack removeStack(int slot, int amount) {
      var stack = Inventories.splitStack(items, slot, amount);
      if (!stack.isEmpty()) markDirty();
      return stack;
    }

    @Override
    public ItemStack removeStack(int slot) {
      var stack = Inventories.removeStack(items, slot);
      markDirty();
      return stack;
    }

    @Override
    public void setStack(int slot, ItemStack stack) {
      items.set(slot, stack);
      stack.capCount(getMaxCountPerStack());
      markDirty();
    }

    @Override
    public void markDirty() {
      dirty.run();
    }

    @Override
    public boolean canPlayerUse(PlayerEntity player) {
      return player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64;
    }

    @Override
    public void clear() {
      items.clear();
      markDirty();
    }

    public Ecology.Survey survey(int animals) {
      int sampled = 0,
          fertile = 0,
          grass = 0,
          water = 0,
          crops = 0,
          trees = 0,
          flowers = 0,
          wetland = 0,
          slopes = 0;
      Set<String> species = new HashSet<>();
      for (Sector s : sectors) {
        sampled += s.lastSampled;
        fertile += s.lastFertile;
        grass += s.lastGrass;
        water += s.lastWater;
        crops += s.lastCrops;
        trees += s.lastTrees;
        flowers += s.lastFlowers;
        wetland += s.lastWetland;
        slopes += s.lastSlopes;
        species.addAll(s.lastSpecies);
      }
      return new Ecology.Survey(
          sampled,
          fertile,
          grass,
          water,
          crops,
          trees,
          flowers,
          species.size(),
          animals,
          (int) species.stream().filter(id -> id.endsWith("_leaves")).count(),
          wetland,
          slopes);
    }

    NbtCompound write(RegistryWrapper.WrapperLookup registries) {
      NbtCompound n = new NbtCompound();
      n.putLong("pos", pos.asLong());
      n.putString("kind", kind);
      n.putInt("compost", compost);
      n.putInt("fuel", fuel);
      n.putInt("water", water);
      n.putInt("resourceVersion", 3);
      n.putInt("culture", culture);
      n.putInt("stableSeconds", stableSeconds);
      n.putInt("rewildCursor", rewildCursor);
      n.putInt("revivalTicks", revivalTicks);
      n.putInt("celebratedStage", celebratedStage);
      n.putBoolean("riverMode", riverMode);
      n.putInt("riverCursor", riverCursor);
      n.putInt("riverRestored", riverRestored);
      n.putString("pendingSpecies", pendingSpecies);
      n.putInt("spreadRadius", spreadRadius);
      n.putInt("spreadTicks", spreadTicks);
      n.putInt("biomeCursor", biomeCursor);
      n.putLongArray("biomeChunks", biomeChunks.stream().mapToLong(Long::longValue).toArray());
      n.putBoolean("registered", registered);
      n.putBoolean("paused", paused);
      Inventories.writeNbt(n, items, registries);
      n.putInt("cursor", cursor);
      n.putInt("sectorCursor", sectorCursor);
      n.putBoolean("production", production);
      n.putBoolean("reclaimed", reclaimed);
      n.putString("biome", biome);
      n.putString("family", family.name());
      n.putLong("lastWildlifeCheck", lastWildlifeCheck);
      n.putString("restoredSpecies", String.join(",", restoredSpecies));
      NbtList list = new NbtList();
      for (Sector s : sectors) list.add(s.write());
      n.put("sectors", list);
      return n;
    }

    static Machine read(NbtCompound n, RegistryWrapper.WrapperLookup registries) {
      Machine m = new Machine(BlockPos.fromLong(n.getLong("pos")), n.getString("kind"));
      m.compost = n.getInt("compost");
      m.fuel = n.getInt("fuel");
      m.water = n.getInt("water");
      m.culture = n.getInt("culture");
      m.stableSeconds = n.getInt("stableSeconds");
      m.rewildCursor = n.getInt("rewildCursor");
      m.revivalTicks = n.getInt("revivalTicks");
      m.celebratedStage = n.getInt("celebratedStage");
      m.riverMode = n.getBoolean("riverMode");
      m.riverCursor = n.getInt("riverCursor");
      m.riverRestored = n.getInt("riverRestored");
      m.pendingSpecies = n.getString("pendingSpecies");
      m.spreadRadius = Math.clamp(n.getInt("spreadRadius"), 1, Balance.MAX_SPREAD_RADIUS);
      m.spreadTicks = n.getInt("spreadTicks");
      m.biomeCursor = n.getInt("biomeCursor");
      for (long chunk : n.getLongArray("biomeChunks")) m.biomeChunks.add(chunk);
      m.registered =
          n.contains("registered") ? n.getBoolean("registered") : m.kind.equals("restoration_core");
      m.paused = n.getBoolean("paused");
      Inventories.readNbt(n, m.items, registries);
      if (n.getInt("resourceVersion") < 2) {
        m.compost = Math.min(Balance.CAPACITY, m.compost * Balance.COMPOST_WORK);
        m.fuel = Math.min(Balance.CAPACITY, m.fuel * 256);
        m.water = Math.min(Balance.CAPACITY, m.water * 64);
        if (m.kind.equals("restoration_core")) m.culture = Balance.CULTURE_WORK;
      }
      if (n.getInt("resourceVersion") < 3) {
        m.compost =
            (int)
                Math.ceil(
                    m.compost
                        * (m.kind.equals("water_restorer") ? 0.5 : Balance.COMPOST_WORK / 256.0));
        m.fuel = (int) Math.ceil(m.fuel * Balance.COAL_WORK / 2048.0);
        m.water =
            Math.min(Balance.TANK_CAPACITY, (int) Math.ceil(m.water * Balance.WATER_WORK / 2048.0));
        m.culture = (int) Math.ceil(m.culture * Balance.CULTURE_WORK / 1024.0);
      }
      m.cursor = n.getInt("cursor");
      m.sectorCursor = n.getInt("sectorCursor");
      m.production = n.getBoolean("production");
      m.reclaimed = n.getBoolean("reclaimed");
      m.biome = n.getString("biome");
      m.lastWildlifeCheck = n.getLong("lastWildlifeCheck");
      if (!n.getString("restoredSpecies").isEmpty())
        m.restoredSpecies.addAll(List.of(n.getString("restoredSpecies").split(",")));
      try {
        m.family = Ecology.Family.valueOf(n.getString("family"));
      } catch (IllegalArgumentException ignored) {
      }
      NbtList list = n.getList("sectors", NbtElement.COMPOUND_TYPE);
      for (int i = 0; i < Math.min(9, list.size()); i++)
        m.sectors[i] = Sector.read(list.getCompound(i));
      return m;
    }
  }

  public static RestorationState get(ServerWorld world) {
    return world.getPersistentStateManager().getOrCreate(TYPE, "reterra");
  }

  @Override
  public NbtCompound writeNbt(NbtCompound n, RegistryWrapper.WrapperLookup registries) {
    n.putInt("version", 2);
    NbtList list = new NbtList();
    machines.values().forEach(m -> list.add(m.write(registries)));
    n.put("machines", list);
    NbtList regions = new NbtList();
    reclaimedRegions.values().forEach(m -> regions.add(m.write(registries)));
    n.put("regions", regions);
    n.putLongArray("protected", protectedBlocks.stream().mapToLong(Long::longValue).toArray());
    NbtList players = new NbtList();
    for (UUID id : startedPlayers) {
      NbtCompound p = new NbtCompound();
      p.putUuid("id", id);
      players.add(p);
    }
    n.put("players", players);
    n.putString("completed", String.join(",", completed.stream().map(Enum::name).toList()));
    n.putBoolean("heart", heartActivated);
    if (heartPos != null) n.putLong("heartPos", heartPos.asLong());
    if (firstSite != null) n.putLong("firstSite", firstSite.asLong());
    n.putBoolean("firstSitePending", firstSitePending);
    n.putInt("firstSiteCursor", firstSiteCursor);
    n.putInt("heartTicks", heartTicks);
    n.putInt("heartCursor", heartCursor);
    NbtList notes = new NbtList();
    discoveries.forEach(
        (id, entries) -> {
          NbtCompound note = new NbtCompound();
          note.putUuid("player", id);
          note.putString("entries", String.join(",", entries));
          notes.add(note);
        });
    n.put("discoveries", notes);
    NbtList sites = new NbtList();
    knownSites.forEach(
        (pos, kind) -> {
          NbtCompound site = new NbtCompound();
          site.putLong("pos", pos);
          site.putString("kind", kind);
          sites.add(site);
        });
    n.put("sites", sites);
    return n;
  }

  public static RestorationState fromNbt(NbtCompound n, RegistryWrapper.WrapperLookup registries) {
    RestorationState s = new RestorationState();
    for (NbtElement e : n.getList("machines", NbtElement.COMPOUND_TYPE)) {
      Machine m = Machine.read((NbtCompound) e, registries);
      m.dirty = s::markDirty;
      if (m.reclaimed) s.reclaimedRegions.put(m.pos.asLong(), m);
      else s.machines.put(m.pos.asLong(), m);
    }
    for (NbtElement e : n.getList("regions", NbtElement.COMPOUND_TYPE)) {
      Machine m = Machine.read((NbtCompound) e, registries);
      m.dirty = s::markDirty;
      s.reclaimedRegions.put(m.pos.asLong(), m);
    }
    for (long p : n.getLongArray("protected")) s.protectedBlocks.add(p);
    for (NbtElement e : n.getList("players", NbtElement.COMPOUND_TYPE))
      s.startedPlayers.add(((NbtCompound) e).getUuid("id"));
    for (String f : n.getString("completed").split(","))
      try {
        s.completed.add(Ecology.Family.valueOf(f));
      } catch (IllegalArgumentException ignored) {
      }
    s.heartActivated = n.getBoolean("heart");
    if (n.contains("heartPos")) s.heartPos = BlockPos.fromLong(n.getLong("heartPos"));
    if (n.contains("firstSite")) s.firstSite = BlockPos.fromLong(n.getLong("firstSite"));
    s.firstSitePending = n.getBoolean("firstSitePending");
    s.firstSiteCursor = n.getInt("firstSiteCursor");
    s.heartTicks = n.getInt("heartTicks");
    s.heartCursor = n.getInt("heartCursor");
    for (NbtElement e : n.getList("discoveries", NbtElement.COMPOUND_TYPE)) {
      NbtCompound note = (NbtCompound) e;
      s.discoveries.put(
          note.getUuid("player"), new HashSet<>(List.of(note.getString("entries").split(","))));
    }
    for (NbtElement e : n.getList("sites", NbtElement.COMPOUND_TYPE)) {
      var site = (NbtCompound) e;
      s.knownSites.put(site.getLong("pos"), site.getString("kind"));
    }
    return s;
  }

  private static RestorationState read(NbtCompound n, RegistryWrapper.WrapperLookup registries) {
    return fromNbt(n, registries);
  }
}
